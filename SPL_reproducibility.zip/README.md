# 本稿代码与模拟结果的唯一公开存档包

SPL_reproducibility.zip 是当前有效代码及冻结模拟结果的投稿复现交付包，不是论文备份。它尚未上传；不能把本地 ZIP 当成已公开仓库。

题目：Directional Likelihood-Ratio Monitoring under a Semiparametric AFT Cure Model。
作者顺序：Meng Cheng, Liu Liu, Xinrui Li, Ye He。

## 内容与边界

- 当前识别/拟合模块、模拟驱动及必要依赖、确定性测试、只读表格生成程序。
- 原始数据/重构模拟/中完整冻结结果：15个OC设置、独立IC检验、全部报警时间、拟合对象、种子、控制限、诊断、配对比较和运行记录。
- 原始数据/决定性审计/中的冻结数值证据及审计代码；原审计涉及的文稿已原位修改，因此不能用历史输入哈希认证现稿。
- 本稿自有临床实施代码，仅以UCI公开原始数据作为输入；不将患者原始或衍生记录重新打包公开，不加入未投稿的论文正文。
- public_manifest.json列出包内每份文件的SHA-256。原运行manifest保留，但公开副本中的本机绝对路径替换为PROJECT/TEMP标签；统计结果与代码未改变。

未打包第三方仓库的原始代码或临时R库；作者公开代码的来源链接及固定commit说明保留。不要把适配实现声称为完整发表流程复现。投稿ZIP打包不跑模拟、不做新拟合。

## 读取与复现

解压后目录仍使用项目的中文目录名。R模拟依赖R4.6.1、penPHcure1.0.2、survival3.8-6；以保留的session_info.txt为环境证据。R库需自行提供，不照抄manifest中已经删除的临时库位置。

只刷新表格（不跑模拟），从解压目录运行：

    Rscript --vanilla 代码/build_simulation_tables.R 项目绝对路径 指定的表格输出目录

确定性估计器测试：

    Rscript --vanilla 代码/tests/test_aftmc_identified.R 项目绝对路径 代码/R/aftmc_identified.R

完整模拟驱动的入口和固定设置见代码/rebuild_simulation.R。原始结果已经保留；复核正文通常只需读表与配对记录。本轮不运行该模拟入口。

临床原始数据独立来源：UCI Heart Failure Clinical Records，https://doi.org/10.24432/C5Z89R （CC BY 4.0）。论文将其限定为事后实施示例，不用于质量报警或长期cure验证。

## 公开上传与正文链接

用户已授权公开代码和模拟结果，并指定 https://github.com/MSCDUT/SPL 。仓库已经确认Public且可读取，但当前连接写入被拒绝（403 Resource not accessible by integration）；仓库仍为空，尚未上传。需要授权连接写入，或作者手动解压上传本包，并保留本稿对应的固定commit链接；DOI不是本文指南强制项。不要把空仓库当作已完成的数据deposit，不编造发布日期或已上传状态。

GitHub：解压ZIP后将其中的目录和文件上传至专门的公开仓库，避免只上传一个无法浏览的ZIP。仓库名称不必带v1/v2。将真实公开链接发回后，再更新文章Data and code availability及数据引文。公开仓库的许可由作者在创建仓库时确认；未将第三方代码重新许可。

本地生成命令：

    python3 代码/辅助/build_public_archive.py 项目绝对路径

每次只覆盖本目录当前ZIP，不保留历史包。
