# Minimal fixed-protocol audit. Does not alter manuscript, formal code or data.
# Rscript decisive_audit.R PROJECT_ROOT OUTPUT_DIR TASK_LOCAL_R_LIBRARY
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==3L)
project <- normalizePath(args[1], mustWork=TRUE)
output <- normalizePath(args[2], mustWork=TRUE)
.libPaths(c(normalizePath(args[3], mustWork=TRUE), .libPaths()))
stopifnot(as.character(utils::packageVersion('smcure'))=='2.2',
          as.character(utils::packageVersion('penPHcure'))=='1.0.2')
options(stringsAsFactors=FALSE, warn=1)
required <- c('core_model.R','ewma.R','monte_carlo.R','semiparametric_aftmc.R',
              'rac_ewma.R','rac_penphcure_adapter.R','m4_shared_misspec_simulation.R')
for (f in required) source(file.path(project,'代码','R',f))
suppressPackageStartupMessages(library(smcure))
started <- Sys.time()
phase1_n <- 1200L
reps <- 400L
horizon <- 200L
target_fap <- 0.10
lambda <- 0.069
chart_rho_c <- 1.5
chart_rho_s <- 0.75
master_seed <- 62610040L
.decisive_em_record <- new.env(parent=emptyenv())
trace('em',where=asNamespace('smcure'),print=FALSE,
      exit=quote(assign('tau',returnValue()$tau,
                        envir=get('.decisive_em_record',envir=.GlobalEnv))))

generate <- function(family,n,seed,rho_c=1,rho_s=1,hazard_multiplier=1) {
  if (family=='neither') {
    return(simulate_m4_shared_misspec(n,incidence_odds_multiplier=rho_c,
              susceptible_time_multiplier=rho_s,seed=seed)[,
      c('tstart','tstop','status','x_incidence','x_latency')])
  }
  set.seed(seed)
  x_incidence <- rnorm(n)
  x_latency <- rbinom(n,1,.5)
  u_cure <- runif(n)
  u_latency <- runif(n)
  u_censor <- runif(n)
  susceptible <- u_cure <= plogis(-.7*x_incidence+log(rho_c))
  if (family=='AFT') {
    susceptible_time <- exp(log(8)-.35*x_latency+.8*qnorm(u_latency))*rho_s
    censor_upper <- aft_censor_upper
  } else if (family=='PH') {
    susceptible_time <- 8*sqrt(expm1(-log(u_latency)/
      (exp(.5*x_latency)*hazard_multiplier)))
    censor_upper <- 30.510331148872091
  } else stop('unknown family')
  event_time <- ifelse(susceptible,susceptible_time,Inf)
  censor_time <- censor_upper*u_censor
  data.frame(tstart=0,tstop=pmin(event_time,censor_time),
             status=as.integer(event_time<=censor_time),
             x_incidence=x_incidence,x_latency=x_latency)
}

# The AFT-true censor bound is deterministically calibrated to 65% censoring
# using the homoscedastic baseline; no OC outcomes enter its selection.
aft_censor_upper <- m4_calibrate_censor_upper(sigma0=.8,sigma1=.8)

baseline_mean <- function(smoother) {
  evaluate <- function(x) evaluate_route_a_log_error(smoother,x,'boundary_complete')$log_survival
  positive <- integrate(function(x) exp(evaluate(x)),0,Inf,
                        subdivisions=500L,rel.tol=1e-9,stop.on.error=TRUE)
  negative <- integrate(function(x) -expm1(evaluate(-x)),0,Inf,
                        subdivisions=500L,rel.tol=1e-9,stop.on.error=TRUE)
  list(mean=positive$value-negative$value,
       integration_error=positive$abs.error+negative$abs.error)
}
center_route <- function(route,location) {
  centered <- route
  centered$latency_coef[1] <- route$latency_coef[1]+location
  centered$residual <- route$residual-location
  centered$nelson_aalen$event_residual <- route$nelson_aalen$event_residual-location
  centered$smoother$nelson_aalen$event_residual <- route$smoother$nelson_aalen$event_residual-location
  centered$smoother$event_range <- route$smoother$event_range-location
  centered$baseline <- route_a_positive_time_baseline(centered$smoother,'boundary_complete')
  centered
}
score_lr <- function(d,route,coef_override=NULL) {
  beta <- if(is.null(coef_override)) route$latency_coef else coef_override
  lp <- route$incidence_coef[1]+route$incidence_coef[2]*d$x_incidence
  aftlp <- beta[1]+beta[2]*d$x_latency
  aft_mixture_log_lr_expanded(d$tstop,d$status,lp,aftlp,
    chart_rho_s,chart_rho_c,
    route_a_positive_time_baseline(route$smoother,'boundary_complete'))
}
cusum_matrix <- function(score) {
  out <- matrix(0,nrow(score),ncol(score)); previous <- numeric(nrow(score))
  for(j in seq_len(ncol(score))) {
    previous <- pmax(0,previous+score[,j]); out[,j] <- previous
  }
  out
}
score_all <- function(d,route,centered,rac_fit) {
  lr <- score_lr(d,route); lr_centered <- score_lr(d,centered)
  prediction <- predict_rac_penphcure(rac_fit,d)
  comp <- rac_component_scores(d$status,prediction$susceptibility_probability,
                              prediction$survival_probability)
  ph_cusum <- comp$posterior_susceptible*log(1.5)+
    d$status*comp$posterior_susceptible*log(1.5)-
    comp$posterior_susceptible*.5*comp$cumulative_hazard
  stopifnot(all(is.finite(c(lr,lr_centered,ph_cusum))))
  list(lr=matrix(lr,reps,horizon,byrow=TRUE),
       lr_centered=matrix(lr_centered,reps,horizon,byrow=TRUE),
       cure=matrix(comp$cure_score,reps,horizon,byrow=TRUE),
       latency=matrix(comp$latency_score,reps,horizon,byrow=TRUE),
       ph_cusum=matrix(ph_cusum,reps,horizon,byrow=TRUE),
       location_lr_max_diff=max(abs(lr-lr_centered)))
}
statistics_all <- function(scores,centers) {
  rac <- rac_ewma_matrices(scores$cure,scores$latency,lambda,lambda,
                          centers$cure,centers$latency)
  list(AFT_LR_EWMA=ewma_matrix(scores$lr,lambda,centers$lr),
       AFT_LR_EWMA_mean_zero=ewma_matrix(scores$lr_centered,lambda,centers$lr),
       AFT_same_LR_CUSUM=cusum_matrix(scores$lr),
       PH_RACure_CUSUM_adaptation=cusum_matrix(scores$ph_cusum),
       RAC_cure=rac$cure,RAC_latency=rac$latency)
}
calibrate <- function(stats,centers) {
  result <- list()
  for(name in c('AFT_LR_EWMA','AFT_same_LR_CUSUM','PH_RACure_CUSUM_adaptation')) {
    threshold <- as.numeric(quantile(apply(stats[[name]],1,max),
                         1-target_fap,type=1))
    # A predeclared floating-point margin avoids treating gauge-roundoff at
    # exactly the empirical calibration maximum as a scientific difference.
    result[[name]] <- threshold+1e-10*max(1,abs(threshold))
  }
  result$AFT_LR_EWMA_mean_zero <- result$AFT_LR_EWMA
  cq <- as.numeric(quantile(stats$RAC_cure,c(.01,.99),type=8))
  lq <- as.numeric(quantile(stats$RAC_latency,c(.01,.99),type=8))
  distance <- c(centers$cure-cq[1],cq[2]-centers$cure,
                centers$latency-lq[1],lq[2]-centers$latency)
  stopifnot(all(is.finite(distance)),all(distance>0))
  maximal <- pmax(apply((centers$cure-stats$RAC_cure)/distance[1],1,max),
                  apply((stats$RAC_cure-centers$cure)/distance[2],1,max),
                  apply((centers$latency-stats$RAC_latency)/distance[3],1,max),
                  apply((stats$RAC_latency-centers$latency)/distance[4],1,max))
  multiplier <- as.numeric(quantile(maximal,1-target_fap,type=1))+1e-10
  result$RAC_EWMA_combined <- c(centers$cure-multiplier*distance[1],
    centers$cure+multiplier*distance[2],centers$latency-multiplier*distance[3],
    centers$latency+multiplier*distance[4])
  result
}
runlengths <- function(stats,limits) {
  out <- lapply(names(limits)[names(limits)!='RAC_EWMA_combined'],function(name)
    upper_run_lengths(stats[[name]],limits[[name]]))
  names(out) <- names(limits)[names(limits)!='RAC_EWMA_combined']
  x <- limits$RAC_EWMA_combined
  out$RAC_EWMA_combined <- rac_combined_run_lengths(stats$RAC_cure,
    stats$RAC_latency,x[1],x[2],x[3],x[4])
  # Independently validate the four-component any-alarm stopping rule.
  independent <- apply(stats$RAC_cure<x[1] | stats$RAC_cure>x[2] |
    stats$RAC_latency<x[3] | stats$RAC_latency>x[4],1,function(v) {
      j <- which(v);if(length(j)) j[1] else horizon+1L
    })
  stopifnot(identical(as.integer(independent),out$RAC_EWMA_combined))
  out
}
wilson <- function(k,n) {
  z <- qnorm(.975); p <- k/n; denom <- 1+z^2/n
  midpoint <- (p+z^2/(2*n))/denom
  radius <- z*sqrt(p*(1-p)/n+z^2/(4*n^2))/denom
  c(midpoint-radius,midpoint+radius)
}
summary_rl <- function(x) {
  detected <- x<=horizon; ci <- wilson(sum(detected),length(x))
  c(detection_probability=mean(detected),probability_mcse=sqrt(mean(detected)*
       (1-mean(detected))/length(x)),probability_ci_low=ci[1],probability_ci_high=ci[2],
    restricted_mean_delay=mean(x),restricted_mean_mcse=sd(x)/sqrt(length(x)),
    detected_only_mean=if(any(detected))mean(x[detected]) else NA,
    no_detection_fraction=mean(!detected))
}
all_summary <- list(); all_raw <- list(); all_location <- list(); all_fits <- list()
all_limits <- list(); all_paths <- list(); all_phase1 <- list()
add_output <- function(family,scenario,role,rls,seeds,gate=NULL) {
  for(name in names(rls)) {
    sm <- summary_rl(rls[[name]])
    eligible <- if(is.null(gate))NA else gate[[name]]
    all_summary[[length(all_summary)+1L]] <<- data.frame(family,scenario,role,
      method=name,as.list(sm),fap_gate_pass=eligible,replicates=reps,horizon,
      target_fap,lambda,seed=seeds)
    all_raw[[length(all_raw)+1L]] <<- data.frame(family,scenario,role,
      method=name,stream=seq_len(reps),run_length=rls[[name]],
      observed_alarm=rls[[name]]<=horizon,seed=seeds)
  }
}
save_checkpoint <- function() {
  write.csv(do.call(rbind,all_summary),file.path(output,'summary.csv'),row.names=FALSE)
  write.csv(do.call(rbind,all_raw),file.path(output,'run_lengths.csv'),row.names=FALSE)
  write.csv(do.call(rbind,all_location),file.path(output,'location_checks.csv'),row.names=FALSE)
  write.csv(do.call(rbind,all_fits),file.path(output,'fit_diagnostics.csv'),row.names=FALSE)
  write.csv(do.call(rbind,all_limits),file.path(output,'control_limits.csv'),row.names=FALSE)
  write.csv(do.call(rbind,all_paths),file.path(output,'representative_paths.csv'),row.names=FALSE)
  write.csv(do.call(rbind,all_phase1),file.path(output,'phase1.csv'),row.names=FALSE)
}

for(index in seq_along(c('AFT','PH','neither'))) {
  family <- c('AFT','PH','neither')[index]
  seed <- master_seed+index*100L
  cat(format(Sys.time()),': fitting',family,'\n'); flush.console()
  phase1 <- generate(family,phase1_n,seed)
  all_phase1[[index]] <- data.frame(family,seed,phase1)
  fit_rac <- fit_rac_penphcure(survival::Surv(tstart,tstop,status)~x_latency,
    ~x_incidence,phase1,standardize=FALSE,ties='breslow',constraint=TRUE)
  fit_aft <- smcure::smcure(survival::Surv(tstop,status)~x_latency,
    cureform=~x_incidence,data=phase1,model='aft',Var=FALSE,emmax=100,eps=1e-7)
  route <- route_a_from_smcure(fit_aft,phase1$tstop,phase1$status,
    cbind(1,phase1$x_incidence),cbind(1,phase1$x_latency),kernel='gaussian',
    bandwidth_multiplier=1)
  location <- baseline_mean(route$smoother)
  centered <- center_route(route,location$mean)
  centered_location <- baseline_mean(centered$smoother)
  stopifnot(abs(centered_location$mean)<1e-6,
            identical(route$latency_coef[2],centered$latency_coef[2]))
  X <- cbind(1,phase1$x_latency)
  official_smsurv <- get('smsurv',asNamespace('smcure'))
  refreshed_s <- official_smsurv(route$residual,phase1$status,X,
    route$latency_coef,fit_aft$logistfit$y,'aft')$survival
  smrank <- get('smrank',asNamespace('smcure'))
  rank_objective <- function(slope) smrank(c(0,slope),Time=phase1$tstop,X=X,
    n=phase1_n,w=route$posterior_uncured,Status=phase1$status)
  rank_original <- rank_objective(route$latency_coef[2])
  slope_check <- optimize(rank_objective,
    interval=route$latency_coef[2]+c(-2,2),tol=1e-7)
  all_fits[[index]] <- data.frame(family,seed,phase1_n,
    observed_event_fraction=mean(phase1$status),
    incidence_intercept=route$incidence_coef[1],incidence_slope=route$incidence_coef[2],
    aft_raw_intercept=route$latency_coef[1],aft_centered_intercept=centered$latency_coef[1],
    aft_slope=route$latency_coef[2],smcure_tau=.decisive_em_record$tau,
    em_tolerance=1e-7,em_converged=.decisive_em_record$tau<=1e-7,
    official_survival_final_update_max_difference=max(abs(fit_aft$s-refreshed_s)),
    frozen_posterior_slope_only_minimum=slope_check$minimum,
    slope_only_change=slope_check$minimum-route$latency_coef[2],
    rank_objective_current=rank_original,rank_objective_slope_only=slope_check$objective,
    rank_objective_relative_reduction=(rank_original-slope_check$objective)/max(1,abs(rank_original)),
    raw_logerror_mean=location$mean,raw_mean_integration_error=location$integration_error,
    centered_logerror_mean=centered_location$mean,
    centered_mean_integration_error=centered_location$integration_error,
    boundary_tail_policy='boundary_complete',bandwidth=route$smoother$bandwidth)
  cat(format(Sys.time()),': scoring calibration',family,'\n');flush.console()
  calibration <- generate(family,reps*horizon,seed+1L)
  cal_scores <- score_all(calibration,route,centered,fit_rac)
  centers <- list(lr=mean(cal_scores$lr),cure=mean(cal_scores$cure),
                  latency=mean(cal_scores$latency))
  cal_stats <- statistics_all(cal_scores,centers)
  limits <- calibrate(cal_stats,centers)
  cal_rl <- runlengths(cal_stats,limits)
  add_output(family,'IC','calibration',cal_rl,seed+1L)
  for(name in names(limits)) all_limits[[length(all_limits)+1L]] <- data.frame(
    family,method=name,limit_index=seq_along(limits[[name]]),value=limits[[name]],
    initial_lr=centers$lr,initial_cure=centers$cure,initial_latency=centers$latency)
  all_location[[length(all_location)+1L]] <- data.frame(family,scenario='IC',
    role='calibration',max_abs_LR_difference=cal_scores$location_lr_max_diff,
    max_abs_EWMA_difference=max(abs(cal_stats$AFT_LR_EWMA-
      cal_stats$AFT_LR_EWMA_mean_zero)),different_alarm_run_lengths=sum(
      cal_rl$AFT_LR_EWMA!=cal_rl$AFT_LR_EWMA_mean_zero),coef_only_broken_max_LR_diff=NA)
  rm(calibration,cal_scores,cal_stats);invisible(gc())
  cat(format(Sys.time()),': scoring heldoutIC',family,'\n');flush.console()
  validation <- generate(family,reps*horizon,seed+2L)
  val_scores <- score_all(validation,route,centered,fit_rac)
  val_stats <- statistics_all(val_scores,centers)
  val_rl <- runlengths(val_stats,limits)
  gate <- lapply(val_rl,function(x) {
    p <- mean(x<=horizon); ci <- wilson(sum(x<=horizon),length(x))
    abs(p-target_fap)<=.04 && ci[1]<=target_fap && ci[2]>=target_fap
  })
  add_output(family,'IC','heldout',val_rl,seed+2L,gate)
  deliberately_broken <- score_lr(validation[seq_len(horizon),],route,
                                  centered$latency_coef)
  broken_diff <- max(abs(deliberately_broken-val_scores$lr[1,]))
  all_location[[length(all_location)+1L]] <- data.frame(family,scenario='IC',
    role='heldout',max_abs_LR_difference=val_scores$location_lr_max_diff,
    max_abs_EWMA_difference=max(abs(val_stats$AFT_LR_EWMA-
      val_stats$AFT_LR_EWMA_mean_zero)),different_alarm_run_lengths=sum(
      val_rl$AFT_LR_EWMA!=val_rl$AFT_LR_EWMA_mean_zero),
    coef_only_broken_max_LR_diff=broken_diff)
  all_paths[[length(all_paths)+1L]] <- data.frame(family,scenario='IC',
    patient=seq_len(horizon),current_logLR=val_scores$lr[1,],
    mean_zero_logLR=val_scores$lr_centered[1,],broken_coef_only_logLR=deliberately_broken,
    current_EWMA=val_stats$AFT_LR_EWMA[1,],mean_zero_EWMA=val_stats$AFT_LR_EWMA_mean_zero[1,])
  rm(validation,val_scores,val_stats);invisible(gc())
  scenarios <- if(family=='AFT') c('matched_joint','magnitude_misspecified') else 'matched_joint'
  for(s in seq_along(scenarios)) {
    scenario <- scenarios[s];oc_seed <- seed+3L+s-1L
    cat(format(Sys.time()),': scoring OC',family,scenario,'\n');flush.console()
    if(family=='PH') {
      oc <- generate(family,reps*horizon,oc_seed,rho_c=1.5,hazard_multiplier=1.5)
    } else if(scenario=='magnitude_misspecified') {
      oc <- generate(family,reps*horizon,oc_seed,rho_c=1.25,rho_s=.875)
    } else oc <- generate(family,reps*horizon,oc_seed,rho_c=1.5,rho_s=.75)
    oc_scores <- score_all(oc,route,centered,fit_rac)
    oc_stats <- statistics_all(oc_scores,centers)
    oc_rl <- runlengths(oc_stats,limits)
    add_output(family,scenario,'OC',oc_rl,oc_seed,gate)
    all_location[[length(all_location)+1L]] <- data.frame(family,scenario,
      role='OC',max_abs_LR_difference=oc_scores$location_lr_max_diff,
      max_abs_EWMA_difference=max(abs(oc_stats$AFT_LR_EWMA-
        oc_stats$AFT_LR_EWMA_mean_zero)),different_alarm_run_lengths=sum(
        oc_rl$AFT_LR_EWMA!=oc_rl$AFT_LR_EWMA_mean_zero),
      coef_only_broken_max_LR_diff=NA)
    all_paths[[length(all_paths)+1L]] <- data.frame(family,scenario,
      patient=seq_len(horizon),current_logLR=oc_scores$lr[1,],
      mean_zero_logLR=oc_scores$lr_centered[1,],broken_coef_only_logLR=NA,
      current_EWMA=oc_stats$AFT_LR_EWMA[1,],mean_zero_EWMA=oc_stats$AFT_LR_EWMA_mean_zero[1,])
    rm(oc,oc_scores,oc_stats);invisible(gc())
  }
  save_checkpoint()
  cat(format(Sys.time()),': finished',family,'elapsed seconds',
      as.numeric(difftime(Sys.time(),started,units='secs')),'\n');flush.console()
}
untrace('em',where=asNamespace('smcure'))
writeLines(capture.output(sessionInfo()),file.path(output,'session_info.txt'))
write.csv(data.frame(key=c('master_seed','phase1_n','calibration_replicates',
  'heldout_replicates','OC_replicates','horizon','target_FAP','lambda',
  'AFT_censor_upper','PH_censor_upper','neither_censor_upper','elapsed_seconds'),
 value=c(master_seed,phase1_n,reps,reps,reps,horizon,target_fap,lambda,
  aft_censor_upper,30.510331148872091,30.510331148872091,
  as.numeric(difftime(Sys.time(),started,units='secs')))),
  file.path(output,'protocol.csv'),row.names=FALSE)
stopifnot(max(do.call(rbind,all_location)$max_abs_LR_difference)<1e-8,
          max(do.call(rbind,all_location)$max_abs_EWMA_difference)<1e-8,
          all(do.call(rbind,all_location)$different_alarm_run_lengths==0))
cat('AUDIT_COMPLETED\n')
