# 当前代码与复现入口

现稿的冻结模拟入口是 rebuild_simulation.R，修正拟合为 R/aftmc_identified.R，表格生成入口为 build_simulation_tables.R。本轮 SPL 压缩没有重跑模拟；只完成已有结果核对、确定性单元测试，以及心衰数据的一次预先固定模型拟合和证据计算。

## 识别与估计

当前 API fit_identified_aftmc：Gehan 阶段固定截距0，只解斜率；proper-tail 完成后用拟合分布均值确定截距，同步平移基线。已核验0或1个连续/二元 latency 协变量；多变量求解器未核验，调用会明确失败。incidence 支持多个协变量。非收敛拟合不得进入监控；smcure 返回的任意截距不能当作零均值 location。

确定性测试不抽随机样本；从项目根目录运行：

    Rscript --vanilla 代码/tests/test_aftmc_identified.R 项目绝对路径 代码/R/aftmc_identified.R

## 当前表格

下列命令只读取已有 CSV，机械刷新文章/manuscript.tex 内的主表及文章目录两份补充表；不进行拟合、校准或模拟：

    Rscript --vanilla 代码/build_simulation_tables.R 项目绝对路径

可选第二参数是指定的临时表格核验目录；默认始终更新唯一当前文章目录，不另建文章版本。

## 冻结的模拟与审计

结果、精确 Phase-I RDS、种子、全部报警时间、诊断和环境记录在原始数据/重构模拟/；manifest 记录实际命令与哈希。模拟使用 R4.6.1、penPHcure1.0.2、survival3.8-6，其他依赖见 session_info.txt。隔离 R 库为临时环境，完成后删除；复现须重新提供同版本库，不能照抄 manifest 中临时路径。penPHcure 源码：https://cran.r-project.org/src/contrib/Archive/penPHcure/penPHcure_1.0.2.tar.gz。

decisive_audit.R、decisive_convergence.R 及依赖保留用于复核 DECISIVE_AUDIT.md。原 M4 驱动和指纹支持已完成原始证据，不是现稿性能依据，不是另存代码版本。任何新模拟须获得用户另行授权；表格生成不能冒充重跑。

RAC-EWMA 为固定官方代码的 formula-level 适配；RACure 作者 score 固定 commit 为 8aa37ac1ec6da99450169886a5b39fb95f676e86。当前另外比较完整 observed-data PH LR，不能与作者 score 适配混称，也不冒充完整发表流程复现。

## 真实数据实施示例

辅助/illustrate_heart_failure.R 按辅助/heart_failure_contract.json 的固定设置，对全部299人做一次拟合，生成原始数据/方法示例/中的模型、系数、逐人 LR、累积器序列、数值核验和 manifest。没有随机样本、误报校准、控制限或报警解释；文件原生行序并非可靠患者到达顺序。该示例不验证长期 cure，也不证明医疗质量变化。

投稿复核时优先读取现有实施结果，不为更新稿件再次拟合或重跑。
