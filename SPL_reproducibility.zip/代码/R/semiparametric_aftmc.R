# Route A post-processing for a rank-based semiparametric AFT mixture-cure fit.
#
# The coefficient fit remains the official smcure AFT fit.  This file adds the
# piece that smcure does not provide: a baseline hazard at arbitrary residual
# times.  Event residuals are placed on the log-error scale, weighted
# Nelson-Aalen increments are formed with the final EM posterior weights, and
# those increments are smoothed with an explicitly selected kernel/bandwidth.

check_equal_length <- function(vectors, names) {
  lengths <- vapply(vectors, length, integer(1))
  if (length(unique(lengths)) != 1L) {
    stop(sprintf("%s must have equal lengths", paste(names, collapse = ", ")), call. = FALSE)
  }
  invisible(lengths[1])
}

weighted_nelson_aalen <- function(residual, status, posterior_uncured) {
  check_binary_status(status)
  check_equal_length(
    list(residual, status, posterior_uncured),
    c("residual", "status", "posterior_uncured")
  )
  if (any(!is.finite(residual))) {
    stop("residuals must be finite", call. = FALSE)
  }
  if (any(!is.finite(posterior_uncured)) ||
      any(posterior_uncured < 0) || any(posterior_uncured > 1)) {
    stop("posterior uncured weights must be finite and in [0, 1]", call. = FALSE)
  }

  event_time <- sort(unique(residual[status == 1]))
  if (length(event_time) < 2L) {
    stop("at least two distinct event residuals are required", call. = FALSE)
  }
  event_count <- vapply(
    event_time,
    function(value) sum(status == 1 & residual == value),
    numeric(1)
  )
  weighted_risk <- vapply(
    event_time,
    function(value) sum(posterior_uncured[residual >= value]),
    numeric(1)
  )
  if (any(!is.finite(weighted_risk)) || any(weighted_risk <= 0)) {
    stop("weighted risk sets must be finite and positive", call. = FALSE)
  }
  increment <- event_count / weighted_risk
  if (any(!is.finite(increment)) || any(increment <= 0)) {
    stop("Nelson-Aalen increments must be finite and positive", call. = FALSE)
  }

  data.frame(
    event_residual = event_time,
    event_count = event_count,
    weighted_risk = weighted_risk,
    increment = increment
  )
}

route_a_kernel_pdf <- function(u, kernel = c("gaussian", "epanechnikov")) {
  kernel <- match.arg(kernel)
  if (kernel == "gaussian") return(dnorm(u))
  value <- numeric(length(u))
  inside <- abs(u) <= 1
  value[inside] <- 0.75 * (1 - u[inside]^2)
  value
}

route_a_kernel_cdf <- function(u, kernel = c("gaussian", "epanechnikov")) {
  kernel <- match.arg(kernel)
  if (kernel == "gaussian") return(pnorm(u))
  value <- numeric(length(u))
  value[u >= 1] <- 1
  inside <- abs(u) < 1
  value[inside] <- 0.5 + 0.75 * (u[inside] - u[inside]^3 / 3)
  value
}

route_a_log_sum_exp <- function(values) {
  if (!length(values)) return(-Inf)
  maximum <- max(values)
  if (!is.finite(maximum)) return(maximum)
  maximum + log(sum(exp(values - maximum)))
}

route_a_default_bandwidth <- function(event_residual) {
  if (length(event_residual) < 2L || any(!is.finite(event_residual))) {
    stop("at least two finite event residuals are required for bandwidth selection", call. = FALSE)
  }
  bandwidth <- bw.nrd0(event_residual)
  if (!is.finite(bandwidth) || bandwidth <= 0) {
    spread <- max(event_residual) - min(event_residual)
    bandwidth <- spread / max(10, sqrt(length(event_residual)))
  }
  check_positive_scalar(bandwidth, "bandwidth")
  bandwidth
}

new_route_a_smoother <- function(
    nelson_aalen,
    bandwidth = NULL,
    kernel = c("gaussian", "epanechnikov"),
    bandwidth_multiplier = 1) {
  kernel <- match.arg(kernel)
  check_positive_scalar(bandwidth_multiplier, "bandwidth_multiplier")
  required <- c("event_residual", "event_count", "weighted_risk", "increment")
  if (!is.data.frame(nelson_aalen) || !all(required %in% names(nelson_aalen))) {
    stop("nelson_aalen has an invalid structure", call. = FALSE)
  }
  if (is.null(bandwidth)) {
    bandwidth <- route_a_default_bandwidth(nelson_aalen$event_residual)
  }
  check_positive_scalar(bandwidth, "bandwidth")
  effective_bandwidth <- bandwidth * bandwidth_multiplier
  check_positive_scalar(effective_bandwidth, "effective bandwidth")

  structure(
    list(
      nelson_aalen = nelson_aalen,
      kernel = kernel,
      reference_bandwidth = bandwidth,
      bandwidth_multiplier = bandwidth_multiplier,
      bandwidth = effective_bandwidth,
      event_range = range(nelson_aalen$event_residual)
    ),
    class = "route_a_smoother"
  )
}

route_a_tail_flags <- function(smoother, residual, boundary_bandwidths = 2) {
  check_positive_scalar(boundary_bandwidths, "boundary_bandwidths")
  lower <- smoother$event_range[1]
  upper <- smoother$event_range[2]
  distance <- boundary_bandwidths * smoother$bandwidth
  data.frame(
    below_event_range = residual < lower,
    above_event_range = residual > upper,
    near_lower_boundary = residual >= lower & residual < lower + distance,
    near_upper_boundary = residual <= upper & residual > upper - distance
  )
}

evaluate_route_a_log_error <- function(
    smoother,
    residual,
    tail_policy = c("error", "evaluate", "boundary_complete"),
    chunk_size = 5000L) {
  if (!inherits(smoother, "route_a_smoother")) {
    stop("smoother must be a route_a_smoother object", call. = FALSE)
  }
  tail_policy <- match.arg(tail_policy)
  if (any(!is.finite(residual))) {
    stop("evaluation residuals must be finite", call. = FALSE)
  }
  if (length(chunk_size) != 1L || !is.finite(chunk_size) ||
      chunk_size < 1 || chunk_size != as.integer(chunk_size)) {
    stop("chunk_size must be one positive integer", call. = FALSE)
  }
  flags <- route_a_tail_flags(smoother, residual)
  outside <- flags$below_event_range | flags$above_event_range
  if (tail_policy == "error" && any(outside)) {
    stop(
      paste(
        "requested residual lies outside the observed event-residual range;",
        "report tail coverage, choose tail_policy='evaluate' for Gaussian",
        "whole-line sensitivity, or use a separately specified",
        "tail_policy='boundary_complete' analysis"
      ),
      call. = FALSE
    )
  }

  event_time <- smoother$nelson_aalen$event_residual
  increment <- smoother$nelson_aalen$increment
  bandwidth <- smoother$bandwidth
  log_survival <- numeric(length(residual))
  log_hazard <- numeric(length(residual))
  starts <- seq.int(1L, length(residual), by = as.integer(chunk_size))
  for (start in starts) {
    index <- start:min(start + as.integer(chunk_size) - 1L, length(residual))
    standardized <- outer(residual[index], event_time, "-") / bandwidth
    kernel_cdf <- route_a_kernel_cdf(standardized, smoother$kernel)
    log_survival[index] <- -drop(kernel_cdf %*% increment)
    if (smoother$kernel == "gaussian") {
      # Work on the log scale so Gaussian-tail evaluations do not underflow to
      # zero merely because the shifted residual is far from the event range.
      log_terms <- sweep(
        dnorm(standardized, log = TRUE),
        2,
        log(increment),
        "+"
      )
      row_maximum <- apply(log_terms, 1, max)
      stabilized <- exp(sweep(log_terms, 1, row_maximum, "-"))
      log_hazard[index] <- row_maximum + log(rowSums(stabilized)) -
        log(bandwidth)
    } else {
      kernel_pdf <- route_a_kernel_pdf(standardized, smoother$kernel)
      hazard <- drop(kernel_pdf %*% increment) / bandwidth
      log_hazard[index] <- ifelse(hazard > 0, log(hazard), -Inf)
    }
  }

  if (tail_policy == "boundary_complete" && any(outside)) {
    boundary <- evaluate_route_a_log_error(
      smoother,
      smoother$event_range,
      tail_policy = "evaluate",
      chunk_size = chunk_size
    )
    cumulative_hazard <- -boundary$log_survival
    boundary_hazard <- exp(boundary$log_hazard)
    if (any(!is.finite(cumulative_hazard)) ||
        any(!is.finite(boundary_hazard)) ||
        any(cumulative_hazard <= 0) || any(boundary_hazard <= 0)) {
      stop("boundary tail completion requires positive finite boundary hazard values", call. = FALSE)
    }

    below <- flags$below_event_range
    if (any(below)) {
      lower <- smoother$event_range[1]
      lower_rate <- boundary_hazard[1] / cumulative_hazard[1]
      distance <- residual[below] - lower
      completed_hazard <- cumulative_hazard[1] * exp(lower_rate * distance)
      log_survival[below] <- -completed_hazard
      log_hazard[below] <- boundary$log_hazard[1] + lower_rate * distance
    }

    above <- flags$above_event_range
    if (any(above)) {
      upper <- smoother$event_range[2]
      distance <- residual[above] - upper
      completed_hazard <- cumulative_hazard[2] + boundary_hazard[2] * distance
      log_survival[above] <- -completed_hazard
      log_hazard[above] <- boundary$log_hazard[2]
    }
  }
  list(
    log_survival = log_survival,
    log_hazard = log_hazard,
    tail_flags = flags
  )
}

route_a_positive_time_baseline <- function(
    smoother,
    tail_policy = c("error", "evaluate", "boundary_complete")) {
  tail_policy <- match.arg(tail_policy)
  force(smoother)
  force(tail_policy)
  function(v) {
    if (any(!is.finite(v)) || any(v <= 0)) {
      stop("positive-time baseline arguments must be finite and positive", call. = FALSE)
    }
    residual <- log(v)
    evaluated <- evaluate_route_a_log_error(smoother, residual, tail_policy)
    # If W = exp(error), h_W(v) = h_error(log(v)) / v.
    list(
      log_survival = evaluated$log_survival,
      log_hazard = evaluated$log_hazard - residual
    )
  }
}

route_a_from_smcure <- function(
    fit,
    time,
    status,
    incidence_matrix,
    latency_matrix,
    bandwidth = NULL,
    kernel = c("gaussian", "epanechnikov"),
    bandwidth_multiplier = 1) {
  kernel <- match.arg(kernel)
  check_binary_status(status)
  n <- check_equal_length(list(time, status), c("time", "status"))
  if (any(!is.finite(time)) || any(time <= 0)) {
    stop("observed times must be finite and positive", call. = FALSE)
  }
  incidence_matrix <- as.matrix(incidence_matrix)
  latency_matrix <- as.matrix(latency_matrix)
  if (nrow(incidence_matrix) != n || nrow(latency_matrix) != n) {
    stop("design matrices must have one row per observation", call. = FALSE)
  }
  required <- c("b", "beta", "s", "Time", "error")
  if (!is.list(fit) || !all(required %in% names(fit))) {
    stop("fit must be an AFT smcure result with b, beta, s, Time, and error", call. = FALSE)
  }
  if (length(fit$b) != ncol(incidence_matrix) ||
      length(fit$beta) != ncol(latency_matrix)) {
    stop("coefficient and design-matrix dimensions do not agree", call. = FALSE)
  }
  if (length(fit$s) != n || length(fit$Time) != n || length(fit$error) != n) {
    stop("smcure result does not match the supplied observations", call. = FALSE)
  }
  if (max(abs(as.numeric(fit$Time) - time)) > 1e-10) {
    stop("supplied times are not in the same order as the smcure fit", call. = FALSE)
  }

  residual <- drop(log(time) - latency_matrix %*% as.numeric(fit$beta))
  if (max(abs(residual - as.numeric(fit$error))) > 1e-7) {
    stop("reconstructed residuals do not agree with smcure; offsets or row order may differ", call. = FALSE)
  }
  probability_uncured <- plogis(drop(incidence_matrix %*% as.numeric(fit$b)))
  official_survival <- as.numeric(fit$s)
  if (any(!is.finite(official_survival)) ||
      any(official_survival < 0) || any(official_survival > 1)) {
    stop("smcure baseline survival values must be finite and in [0, 1]", call. = FALSE)
  }
  denominator <- 1 - probability_uncured + probability_uncured * official_survival
  posterior_uncured <- status + (1 - status) *
    probability_uncured * official_survival / denominator
  nelson_aalen <- weighted_nelson_aalen(residual, status, posterior_uncured)
  smoother <- new_route_a_smoother(
    nelson_aalen = nelson_aalen,
    bandwidth = bandwidth,
    kernel = kernel,
    bandwidth_multiplier = bandwidth_multiplier
  )

  structure(
    list(
      incidence_coef = as.numeric(fit$b),
      latency_coef = as.numeric(fit$beta),
      probability_uncured = probability_uncured,
      official_survival = official_survival,
      posterior_uncured = posterior_uncured,
      residual = residual,
      nelson_aalen = nelson_aalen,
      smoother = smoother,
      baseline = route_a_positive_time_baseline(smoother, tail_policy = "error"),
      weight_source = "final posterior calculation using survival returned by official smcure"
    ),
    class = "route_a_aftmc"
  )
}

route_a_shift_coverage <- function(route_a_fit, residual_null, rho_s) {
  if (!inherits(route_a_fit, "route_a_aftmc")) {
    stop("route_a_fit must be a route_a_aftmc object", call. = FALSE)
  }
  check_positive_scalar(rho_s, "rho_s")
  shifted <- residual_null - log(rho_s)
  lower <- route_a_fit$smoother$event_range[1]
  upper <- route_a_fit$smoother$event_range[2]
  in_null <- residual_null >= lower & residual_null <= upper
  in_shifted <- shifted >= lower & shifted <= upper
  c(
    null_coverage = mean(in_null),
    shifted_coverage = mean(in_shifted),
    joint_coverage = mean(in_null & in_shifted)
  )
}
