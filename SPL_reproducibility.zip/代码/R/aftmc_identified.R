# Identified rank-based semiparametric AFT mixture-cure estimation.
# Source core_model.R and semiparametric_aftmc.R before this module.
#
# The Gehan rank objective estimates slopes only.  The computational location
# is fixed at zero during rank updates.  A proper post-fit error distribution
# then defines the intercept by its mean, with a simultaneous baseline shift.
# These are EM-type rank updates, not a claimed likelihood-ascent algorithm.

aftmc_rank_cache <- function(logtime, status, latency) {
  latency <- as.matrix(latency)
  n <- length(logtime)
  if (nrow(latency) != n || ncol(latency) > 1L) {
    stop("this exact rank solver requires zero or one latency covariate", call. = FALSE)
  }
  events <- which(status == 1L)
  if (length(events) < 2L) stop("at least two events are required", call. = FALSE)
  if (!ncol(latency)) return(list(n = n, events = events, latency = latency,
                                logtime = logtime, dimension = 0L))
  # Pair orientation: i is an event; j contributes posterior weight w_j.
  # a_ij = logY_j-logY_i; d_ij = z_j-z_i; objective is sum w_j(a_ij-b*d_ij)_+.
  ai <- outer(logtime[events], logtime, function(i, j) j-i)
  dx <- outer(latency[events, 1], latency[, 1], function(i, j) j-i)
  j <- rep(seq_len(n), each = length(events))
  nonzero <- as.vector(dx) != 0
  a <- as.vector(ai)[nonzero]
  d <- as.vector(dx)[nonzero]
  j <- j[nonzero]
  if (!length(d) || !any(d > 0) || !any(d < 0)) {
    stop("latency covariate does not identify a finite two-sided rank slope", call. = FALSE)
  }
  breakpoint <- a/d
  ord <- order(breakpoint, j, d)
  list(n = n, events = events, latency = latency, logtime = logtime,
       dimension = 1L, breakpoint = breakpoint[ord], d = d[ord], j = j[ord],
       a = a[ord])
}

aftmc_gehan_objective <- function(slope, logtime, status, latency, posterior) {
  latency <- as.matrix(latency)
  residual <- logtime - drop(latency %*% slope)
  events <- which(status == 1L)
  differences <- outer(residual[events], residual, function(i, j) j-i)
  sum(sweep(pmax(differences, 0), 2, posterior, "*"))/length(logtime)
}

aftmc_rank_update <- function(cache, posterior) {
  if (!cache$dimension) return(list(slope = numeric(), certificate = 0,
                                  left_derivative = 0, right_derivative = 0))
  weights <- posterior[cache$j] * abs(cache$d)
  total <- sum(weights)
  positive <- sum(weights[cache$d > 0])
  negative <- total-positive
  if (!is.finite(total) || min(positive, negative) <= 0) {
    stop("posterior weights do not identify a finite two-sided rank slope", call. = FALSE)
  }
  cumulative <- cumsum(weights)
  hit <- which(cumulative >= positive)[1L]
  slope <- cache$breakpoint[hit]
  # Exact flat interval: choose its midpoint, not an arbitrary optimizer gauge.
  tol <- 1e-12 * max(1, total)
  at <- cache$breakpoint == slope
  before <- sum(weights[cache$breakpoint < slope])
  through <- before + sum(weights[at])
  next_break <- cache$breakpoint[cache$breakpoint > slope & weights > 0]
  if (abs(through-positive) <= tol && length(next_break)) {
    slope <- (slope+min(next_break))/2
    before <- sum(weights[cache$breakpoint < slope])
    through <- sum(weights[cache$breakpoint <= slope])
  }
  left <- (-positive+before)/cache$n
  right <- (-positive+through)/cache$n
  certificate <- max(left, -right, 0)/(total/cache$n)
  if (!is.finite(certificate) || certificate > 1e-10) {
    stop("Gehan slope update failed the convex subgradient certificate", call. = FALSE)
  }
  list(slope = as.numeric(slope), certificate = certificate,
       left_derivative = left, right_derivative = right)
}

aftmc_step_nelson_aalen <- function(residual, status, posterior) {
  # Inclusive risk sets e_j>=e_i and inclusive jump convention tau<=r.
  ord <- order(residual, decreasing = TRUE)
  r <- residual[ord]
  group <- cumsum(c(TRUE, diff(r) != 0))
  event_count <- drop(rowsum(status[ord], group, reorder = FALSE))
  risk <- cumsum(drop(rowsum(posterior[ord], group, reorder = FALSE)))
  node <- r[!duplicated(group)]
  keep <- event_count > 0
  if (sum(keep) < 2L || any(risk[keep] <= 0)) {
    stop("fewer than two usable distinct event residuals or empty risk set", call. = FALSE)
  }
  answer <- data.frame(event_residual = node[keep], event_count = event_count[keep],
                       weighted_risk = risk[keep], increment = event_count[keep]/risk[keep])
  answer[order(answer$event_residual), , drop = FALSE]
}

aftmc_step_survival <- function(nelson_aalen, residual, terminal_zero = TRUE) {
  index <- findInterval(residual, nelson_aalen$event_residual)
  cumulative <- c(0, cumsum(nelson_aalen$increment))
  survival <- exp(-cumulative[index+1L])
  # The same sufficient-follow-up tail convention used by official smcure:
  # residuals strictly beyond the final event have zero susceptible survival.
  if (terminal_zero) survival[residual > max(nelson_aalen$event_residual)] <- 0
  survival
}

aftmc_posterior <- function(status, incidence_lp, susceptible_survival) {
  p <- plogis(incidence_lp)
  denominator <- 1-p+p*susceptible_survival
  if (any(!is.finite(denominator)) || any(denominator <= 0)) {
    stop("invalid mixture survivor in posterior update", call. = FALSE)
  }
  status + (1-status)*p*susceptible_survival/denominator
}

aftmc_logistic_update <- function(incidence_matrix, posterior, start = NULL) {
  # Fractional posterior responses maximize the expected Bernoulli loglik.
  # Quasibinomial uses the identical logit score without a noninteger warning;
  # no quasi-likelihood variance or likelihood value is used downstream.
  fit <- stats::glm.fit(incidence_matrix, posterior,
                        family = stats::quasibinomial(link = "logit"),
                        start = start, control = stats::glm.control(epsilon = 1e-10,
                                                                  maxit = 100))
  if (!isTRUE(fit$converged) || any(!is.finite(fit$coefficients))) {
    stop("logistic incidence update did not converge", call. = FALSE)
  }
  as.numeric(fit$coefficients)
}

aftmc_error_mean <- function(smoother, relative_tolerance = 1e-9) {
  logS <- function(x) evaluate_route_a_log_error(smoother, x,
                                                tail_policy = "boundary_complete")$log_survival
  positive <- stats::integrate(function(x) exp(logS(x)), 0, Inf,
                               subdivisions = 500L, rel.tol = relative_tolerance,
                               stop.on.error = TRUE)
  negative <- stats::integrate(function(x) -expm1(logS(-x)), 0, Inf,
                               subdivisions = 500L, rel.tol = relative_tolerance,
                               stop.on.error = TRUE)
  list(mean = positive$value-negative$value,
       integration_error = positive$abs.error+negative$abs.error)
}

aftmc_center_route <- function(route, location) {
  centered <- route
  centered$latency_coef[1] <- route$latency_coef[1]+location
  centered$residual <- route$residual-location
  centered$nelson_aalen$event_residual <- route$nelson_aalen$event_residual-location
  centered$smoother$nelson_aalen$event_residual <-
    route$smoother$nelson_aalen$event_residual-location
  centered$smoother$event_range <- route$smoother$event_range-location
  centered$baseline <- route_a_positive_time_baseline(centered$smoother,
                                                     tail_policy = "boundary_complete")
  centered
}

fit_identified_aftmc <- function(
    data, incidence_vars = "x_incidence", latency_vars = "x_latency",
    time_var = "tstop", status_var = "status", control = list()) {
  defaults <- list(maxit = 500L, coef_tol = 1e-5, survivor_tol = 1e-5,
                   posterior_tol = 1e-5, stable_iterations = 2L,
                   kernel = "gaussian", bandwidth_multiplier = 1,
                   terminal_zero = TRUE, mean_tol = 1e-6, verbose = FALSE)
  unknown <- setdiff(names(control), names(defaults))
  if (length(unknown)) stop(paste("unknown control:", paste(unknown, collapse = ", ")),
                            call. = FALSE)
  control <- utils::modifyList(defaults, control)
  stopifnot(control$maxit >= 1, control$stable_iterations >= 1,
            control$coef_tol > 0, control$survivor_tol > 0,
            control$posterior_tol > 0, control$mean_tol > 0)
  required <- unique(c(time_var, status_var, incidence_vars, latency_vars))
  if (!is.data.frame(data) || !all(required %in% names(data))) {
    stop("data are missing specified estimation columns", call. = FALSE)
  }
  time <- as.numeric(data[[time_var]])
  check_binary_status(data[[status_var]])
  status <- as.integer(data[[status_var]])
  if (any(!is.finite(time)) || any(time <= 0)) stop("times must be finite and positive",
                                                                call. = FALSE)
  incidence <- cbind(`(Intercept)` = 1, as.matrix(data[, incidence_vars, drop = FALSE]))
  latency <- as.matrix(data[, latency_vars, drop = FALSE])
  if (any(!is.finite(incidence)) || any(!is.finite(latency)) ||
      qr(incidence)$rank < ncol(incidence)) {
    stop("design matrices contain nonfinite values or unidentified incidence directions",
         call. = FALSE)
  }
  logtime <- log(time)
  cache <- aftmc_rank_cache(logtime, status, latency)
  posterior <- rep(1, length(time))
  slope <- aftmc_rank_update(cache, posterior)$slope
  incidence_coef <- aftmc_logistic_update(incidence, status)
  residual <- logtime-drop(latency %*% slope)
  nelson_aalen <- aftmc_step_nelson_aalen(residual, status, posterior)
  survival <- aftmc_step_survival(nelson_aalen, residual, control$terminal_zero)
  mixture_survival <- 1-plogis(drop(incidence %*% incidence_coef))*(1-survival)
  history <- vector("list", as.integer(control$maxit))
  stable <- 0L
  converged <- FALSE
  for (iteration in seq_len(as.integer(control$maxit))) {
    updated_posterior <- aftmc_posterior(status, drop(incidence %*% incidence_coef), survival)
    updated_incidence <- aftmc_logistic_update(incidence, updated_posterior, incidence_coef)
    rank <- aftmc_rank_update(cache, updated_posterior)
    updated_slope <- rank$slope
    updated_residual <- logtime-drop(latency %*% updated_slope)
    # No stale residual: risk sets are recomputed after the slope update.
    updated_na <- aftmc_step_nelson_aalen(updated_residual, status, updated_posterior)
    updated_survival <- aftmc_step_survival(updated_na, updated_residual, control$terminal_zero)
    updated_mixture <- 1-plogis(drop(incidence %*% updated_incidence))*(1-updated_survival)
    coef_change <- max(abs(c(updated_incidence-incidence_coef, updated_slope-slope))/
                         (1+abs(c(incidence_coef, slope))))
    survivor_change <- max(abs(updated_survival-survival))
    mixture_change <- max(abs(updated_mixture-mixture_survival))
    posterior_change <- max(abs(updated_posterior-posterior))
    passed <- coef_change <= control$coef_tol &&
      survivor_change <= control$survivor_tol && mixture_change <= control$survivor_tol &&
      posterior_change <= control$posterior_tol
    stable <- if (passed) stable+1L else 0L
    history[[iteration]] <- data.frame(iteration, coef_change, survivor_change,
                                      mixture_survivor_change = mixture_change,
                                      posterior_change, rank_certificate = rank$certificate,
                                      rank_slope = if (length(updated_slope)) updated_slope else NA_real_,
                                      passed, stable_iterations = stable)
    incidence_coef <- updated_incidence
    slope <- updated_slope
    residual <- updated_residual
    nelson_aalen <- updated_na
    survival <- updated_survival
    mixture_survival <- updated_mixture
    posterior <- updated_posterior
    if (isTRUE(control$verbose) && (iteration %% 20L == 0L || stable > 0L)) {
      message(sprintf("rank EM %d: coef %.3g survivor %.3g posterior %.3g",
                      iteration, coef_change, survivor_change, posterior_change))
    }
    if (stable >= control$stable_iterations) {
      converged <- TRUE
      break
    }
  }
  history <- do.call(rbind, history[seq_len(iteration)])
  if (!converged) {
    condition <- structure(list(message = sprintf(
      "identified AFT rank iteration failed to converge in %d iterations (coef=%g, survivor=%g, posterior=%g)",
      iteration, coef_change, survivor_change, posterior_change), call = NULL,
      history = history, control = control), class = c("aftmc_convergence_error", "error", "condition"))
    stop(condition)
  }
  # Final posterior is computed at the accepted updated residuals and parameters.
  final_posterior <- aftmc_posterior(status, drop(incidence %*% incidence_coef), survival)
  final_na <- aftmc_step_nelson_aalen(residual, status, final_posterior)
  final_survival <- aftmc_step_survival(final_na, residual, control$terminal_zero)
  final_prediction_change <- max(abs(final_survival-survival))
  final_posterior_change <- max(abs(final_posterior-posterior))
  if (final_prediction_change > control$survivor_tol ||
      final_posterior_change > control$posterior_tol) {
    stop("final fixed-point refresh exceeded the declared convergence tolerance", call. = FALSE)
  }
  smoother <- new_route_a_smoother(final_na, kernel = control$kernel,
                                  bandwidth_multiplier = control$bandwidth_multiplier)
  raw <- structure(list(incidence_coef = incidence_coef, latency_coef = c(0, slope),
                        probability_uncured = plogis(drop(incidence %*% incidence_coef)),
                        official_survival = final_survival, posterior_uncured = final_posterior,
                        residual = residual, nelson_aalen = final_na, smoother = smoother,
                        baseline = route_a_positive_time_baseline(smoother, "boundary_complete"),
                        incidence_vars = incidence_vars, latency_vars = latency_vars,
                        weight_source = "identified rank iteration; refreshed posterior and updated residual risk sets"),
                   class = "route_a_aftmc")
  location <- aftmc_error_mean(raw$smoother)
  route <- aftmc_center_route(raw, location$mean)
  centered_mean <- aftmc_error_mean(route$smoother)
  if (!is.finite(centered_mean$mean) || abs(centered_mean$mean) > control$mean_tol) {
    stop("proper error distribution failed the mean-zero normalization check", call. = FALSE)
  }
  route$diagnostics <- list(converged = TRUE, iterations = iteration,
                            coef_change = coef_change, survivor_change = survivor_change,
                            mixture_survivor_change = mixture_change,
                            posterior_change = posterior_change,
                            final_prediction_change = final_prediction_change,
                            final_posterior_change = final_posterior_change,
                            rank_certificate = rank$certificate,
                            centering_mean_raw = location$mean,
                            mean_after_centering = centered_mean$mean,
                            mean_integration_error = max(location$integration_error,
                                                         centered_mean$integration_error),
                            history = history, control = control,
                            estimation_location = 0,
                            tail_policy = "boundary_complete",
                            estimation_tail = "S(r)=0 strictly beyond the last event residual")
  route
}

predict_identified_aftmc <- function(route, data, time_var = "tstop") {
  if (!inherits(route, "route_a_aftmc") || !isTRUE(route$diagnostics$converged) ||
      !identical(route$diagnostics$tail_policy, "boundary_complete")) {
    stop("prediction requires a converged identified proper-tail AFT route", call. = FALSE)
  }
  variables <- unique(c(route$incidence_vars, route$latency_vars, time_var))
  if (!all(variables %in% names(data))) stop("prediction variables are missing", call. = FALSE)
  incidence <- cbind(1, as.matrix(data[, route$incidence_vars, drop = FALSE]))
  latency <- cbind(1, as.matrix(data[, route$latency_vars, drop = FALSE]))
  time <- as.numeric(data[[time_var]])
  if (any(!is.finite(incidence)) || any(!is.finite(latency)) ||
      any(!is.finite(time)) || any(time <= 0)) {
    stop("prediction values must be finite and times positive", call. = FALSE)
  }
  incidence_lp <- drop(incidence %*% route$incidence_coef)
  aft_lp <- drop(latency %*% route$latency_coef)
  baseline <- route$baseline(time*exp(-aft_lp))
  list(incidence_lp = incidence_lp, aft_lp = aft_lp,
       probability_uncured = plogis(incidence_lp),
       susceptible_log_survival = baseline$log_survival,
       population_survival = 1-plogis(incidence_lp)*(1-exp(baseline$log_survival)))
}

identified_aftmc_log_lr <- function(route, data, rho_c, rho_s,
                                   time_var = "tstop", status_var = "status") {
  prediction <- predict_identified_aftmc(route, data, time_var)
  aft_mixture_log_lr_expanded(data[[time_var]], data[[status_var]],
                            prediction$incidence_lp, prediction$aft_lp,
                            rho_s, rho_c, route$baseline)
}
