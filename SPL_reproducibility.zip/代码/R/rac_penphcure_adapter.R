# Optional adapter between a Phase I penPHcure fit and the formula-level
# RAC-EWMA implementation. The adapter is sourced safely when penPHcure is not
# installed; fitting fails with an explicit message rather than substituting a
# different model.

fit_rac_penphcure <- function(formula,
                              cureform,
                              data,
                              standardize = FALSE,
                              ties = "breslow",
                              constraint = TRUE,
                              max_iterations_nr = 500L,
                              max_iterations_em = 500L,
                              tolerance = 1e-6) {
  if (!requireNamespace("penPHcure", quietly = TRUE)) {
    stop(
      paste(
        "penPHcure is not installed.",
        "See validation/PENPHCURE_SOURCE.md for the fixed archived version."
      ),
      call. = FALSE
    )
  }
  if (!is.data.frame(data) || nrow(data) == 0L) {
    stop("Phase I data must be a nonempty data frame", call. = FALSE)
  }
  penPHcure::penPHcure(
    formula = formula,
    cureform = cureform,
    data = data,
    standardize = standardize,
    ties = ties,
    constraint = constraint,
    maxIterNR = max_iterations_nr,
    maxIterEM = max_iterations_em,
    tol = tolerance,
    inference = FALSE,
    pen.type = "none",
    print.details = FALSE,
    warnings = TRUE
  )
}

rac_validate_penphcure_prediction <- function(prediction, expected_length) {
  if (!is.list(prediction) ||
      !all(c("CURE", "SURV") %in% names(prediction))) {
    stop("penPHcure prediction must contain CURE and SURV", call. = FALSE)
  }
  if (length(expected_length) != 1L || !is.finite(expected_length) ||
      expected_length < 1 || expected_length != as.integer(expected_length)) {
    stop("expected_length must be one positive integer", call. = FALSE)
  }
  if (length(prediction$CURE) != expected_length ||
      length(prediction$SURV) != expected_length) {
    stop("penPHcure prediction length does not match the monitoring data", call. = FALSE)
  }
  # This also enforces finite values and the domains required by the RAC score.
  rac_validate_equal_vectors(
    status = rep(0, expected_length),
    susceptibility_probability = prediction$CURE,
    survival_probability = prediction$SURV
  )
  invisible(TRUE)
}

predict_rac_penphcure <- function(fit, newdata) {
  if (!is.data.frame(newdata) || nrow(newdata) == 0L) {
    stop("monitoring data must be a nonempty data frame", call. = FALSE)
  }
  prediction <- stats::predict(fit, newdata = newdata)
  rac_validate_penphcure_prediction(prediction, nrow(newdata))
  data.frame(
    susceptibility_probability = as.numeric(prediction$CURE),
    survival_probability = as.numeric(prediction$SURV)
  )
}

rac_scores_from_penphcure <- function(fit, newdata, status) {
  prediction <- predict_rac_penphcure(fit, newdata)
  if (length(status) != nrow(newdata)) {
    stop("status length does not match the monitoring data", call. = FALSE)
  }
  rac_component_scores(
    status = status,
    susceptibility_probability = prediction$susceptibility_probability,
    survival_probability = prediction$survival_probability
  )
}
