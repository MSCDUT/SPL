# Shared-misspecification mixture-cure generator for the M4 comparison.
# The cure predictor contains an omitted quadratic term and susceptible log
# times have a covariate-dependent error scale. The fitted linear logistic,
# common-error AFT, and PH models are therefore all deliberately misspecified.

m4_expected_susceptibility <- function(
    intercept,
    linear_coef = -0.7,
    quadratic_coef = 0.45,
    relative_tolerance = 1e-11) {
  parameters <- c(intercept, linear_coef, quadratic_coef, relative_tolerance)
  if (any(!is.finite(parameters)) || relative_tolerance <= 0) {
    stop("invalid M4 incidence integration parameters", call. = FALSE)
  }
  integrand <- function(x) {
    stats::plogis(
      intercept + linear_coef * x + quadratic_coef * (x^2 - 1)
    ) * stats::dnorm(x)
  }
  stats::integrate(
    integrand,
    lower = -Inf,
    upper = Inf,
    rel.tol = relative_tolerance,
    subdivisions = 500L,
    stop.on.error = TRUE
  )$value
}

m4_calibrate_incidence_intercept <- function(
    target_susceptibility = 0.5,
    linear_coef = -0.7,
    quadratic_coef = 0.45,
    relative_tolerance = 1e-11) {
  if (length(target_susceptibility) != 1L ||
      !is.finite(target_susceptibility) || target_susceptibility <= 0 ||
      target_susceptibility >= 1) {
    stop("target_susceptibility must lie in (0, 1)", call. = FALSE)
  }
  objective <- function(intercept) {
    m4_expected_susceptibility(
      intercept,
      linear_coef,
      quadratic_coef,
      relative_tolerance
    ) - target_susceptibility
  }
  stats::uniroot(objective, c(-30, 30), tol = relative_tolerance)$root
}

m4_logtime_quantile_ratio <- function(
    probability,
    latency_coef = -0.35,
    sigma0 = 0.65,
    sigma1 = 1.05) {
  parameters <- c(latency_coef, sigma0, sigma1)
  if (!is.numeric(probability) || !length(probability) ||
      any(!is.finite(probability)) || any(probability <= 0 | probability >= 1) ||
      any(!is.finite(parameters)) || sigma0 <= 0 || sigma1 <= 0) {
    stop("invalid M4 quantile-ratio inputs", call. = FALSE)
  }
  exp(latency_coef + (sigma1 - sigma0) * stats::qnorm(probability))
}

m4_cumulative_hazard_ratio <- function(
    time,
    latency_intercept = log(8),
    latency_coef = -0.35,
    sigma0 = 0.65,
    sigma1 = 1.05) {
  parameters <- c(latency_intercept, latency_coef, sigma0, sigma1)
  if (!is.numeric(time) || !length(time) || any(!is.finite(time)) ||
      any(time <= 0) || any(!is.finite(parameters)) || sigma0 <= 0 ||
      sigma1 <= 0) {
    stop("invalid M4 cumulative-hazard-ratio inputs", call. = FALSE)
  }
  log_survival <- function(z, sigma) {
    stats::pnorm(
      (latency_intercept + latency_coef * z - log(time)) / sigma,
      log.p = TRUE
    )
  }
  (-log_survival(1, sigma1)) / (-log_survival(0, sigma0))
}

m4_expected_susceptible_event_fraction <- function(
    censor_upper,
    latency_intercept = log(8),
    latency_coef = -0.35,
    sigma0 = 0.65,
    sigma1 = 1.05) {
  parameters <- c(
    censor_upper,
    latency_intercept,
    latency_coef,
    sigma0,
    sigma1
  )
  if (any(!is.finite(parameters)) || censor_upper <= 0 || sigma0 <= 0 ||
      sigma1 <= 0) {
    stop("invalid M4 censoring parameters", call. = FALSE)
  }
  components <- mapply(
    function(z, sigma) {
      location <- latency_intercept + latency_coef * z
      standardized <- (log(censor_upper) - location) / sigma
      probability_below <- stats::pnorm(standardized)
      truncated_mean <- exp(location + sigma^2 / 2) *
        stats::pnorm(standardized - sigma)
      probability_below - truncated_mean / censor_upper
    },
    z = 0:1,
    sigma = c(sigma0, sigma1)
  )
  mean(components)
}

m4_calibrate_censor_upper <- function(
    target_total_censoring = 0.65,
    marginal_susceptibility = 0.5,
    latency_intercept = log(8),
    latency_coef = -0.35,
    sigma0 = 0.65,
    sigma1 = 1.05,
    relative_tolerance = 1e-11) {
  fractions <- c(target_total_censoring, marginal_susceptibility)
  if (any(!is.finite(fractions)) || any(fractions <= 0 | fractions >= 1) ||
      target_total_censoring <= 1 - marginal_susceptibility ||
      !is.finite(relative_tolerance) || relative_tolerance <= 0) {
    stop("invalid M4 censoring calibration target", call. = FALSE)
  }
  target_susceptible_event <-
    (1 - target_total_censoring) / marginal_susceptibility
  objective <- function(upper) {
    m4_expected_susceptible_event_fraction(
      upper,
      latency_intercept,
      latency_coef,
      sigma0,
      sigma1
    ) - target_susceptible_event
  }
  upper <- 1
  while (objective(upper) < 0 && upper < 1e8) upper <- upper * 2
  if (upper >= 1e8 && objective(upper) < 0) {
    stop("could not bracket the M4 censoring root", call. = FALSE)
  }
  stats::uniroot(objective, c(.Machine$double.eps, upper),
                 tol = relative_tolerance)$root
}

simulate_m4_shared_misspec <- function(
    n,
    incidence_intercept = 0.079099272918428,
    incidence_linear_coef = -0.7,
    incidence_quadratic_coef = 0.45,
    latency_intercept = log(8),
    latency_coef = -0.35,
    sigma0 = 0.65,
    sigma1 = 1.05,
    censor_upper = 30.510331148872091,
    incidence_odds_multiplier = 1,
    susceptible_time_multiplier = 1,
    x_incidence = NULL,
    x_latency = NULL,
    susceptibility_uniform = NULL,
    latency_normal = NULL,
    censor_uniform = NULL,
    seed = NULL) {
  if (length(n) != 1L || !is.finite(n) || n < 1 || n != as.integer(n)) {
    stop("n must be one positive integer", call. = FALSE)
  }
  n <- as.integer(n)
  parameters <- c(
    incidence_intercept,
    incidence_linear_coef,
    incidence_quadratic_coef,
    latency_intercept,
    latency_coef,
    sigma0,
    sigma1,
    censor_upper,
    incidence_odds_multiplier,
    susceptible_time_multiplier
  )
  if (any(!is.finite(parameters)) || sigma0 <= 0 || sigma1 <= 0 ||
      censor_upper <= 0 || incidence_odds_multiplier <= 0 ||
      susceptible_time_multiplier <= 0) {
    stop("invalid M4 generator parameters", call. = FALSE)
  }
  if (!is.null(seed)) {
    if (length(seed) != 1L || !is.finite(seed)) {
      stop("seed must be one finite value", call. = FALSE)
    }
    set.seed(seed)
  }

  validate_numeric <- function(value, name) {
    if (!is.numeric(value) || length(value) != n || any(!is.finite(value))) {
      stop(sprintf("%s must be a finite numeric vector of length n", name),
           call. = FALSE)
    }
    value
  }
  validate_uniform <- function(value, name) {
    value <- validate_numeric(value, name)
    if (any(value <= 0 | value >= 1)) {
      stop(sprintf("%s must lie strictly between zero and one", name),
           call. = FALSE)
    }
    value
  }

  if (is.null(x_incidence)) x_incidence <- stats::rnorm(n)
  if (is.null(x_latency)) x_latency <- stats::rbinom(n, 1, 0.5)
  if (is.null(susceptibility_uniform)) susceptibility_uniform <- stats::runif(n)
  if (is.null(latency_normal)) latency_normal <- stats::rnorm(n)
  if (is.null(censor_uniform)) censor_uniform <- stats::runif(n)
  x_incidence <- validate_numeric(x_incidence, "x_incidence")
  x_latency <- validate_numeric(x_latency, "x_latency")
  if (any(!(x_latency %in% c(0, 1)))) {
    stop("x_latency must contain only zero and one", call. = FALSE)
  }
  susceptibility_uniform <- validate_uniform(
    susceptibility_uniform,
    "susceptibility_uniform"
  )
  latency_normal <- validate_numeric(latency_normal, "latency_normal")
  censor_uniform <- validate_uniform(censor_uniform, "censor_uniform")

  incidence_lp <- incidence_intercept + incidence_linear_coef * x_incidence +
    incidence_quadratic_coef * (x_incidence^2 - 1) +
    log(incidence_odds_multiplier)
  susceptibility_probability <- stats::plogis(incidence_lp)
  susceptible <- as.integer(
    susceptibility_uniform <= susceptibility_probability
  )
  latency_sigma <- ifelse(x_latency == 0, sigma0, sigma1)
  log_susceptible_time <- latency_intercept + latency_coef * x_latency +
    latency_sigma * latency_normal + log(susceptible_time_multiplier)
  susceptible_time <- exp(log_susceptible_time)
  true_event_time <- ifelse(susceptible == 1L, susceptible_time, Inf)
  censor_time <- censor_upper * censor_uniform
  tstop <- pmin(true_event_time, censor_time)
  status <- as.integer(true_event_time <= censor_time)

  data.frame(
    id = seq_len(n),
    tstart = 0,
    tstop = tstop,
    status = status,
    x_incidence = x_incidence,
    x_latency = x_latency,
    susceptible = susceptible,
    susceptibility_probability = susceptibility_probability,
    incidence_lp = incidence_lp,
    latency_sigma = latency_sigma,
    true_event_time = true_event_time,
    censor_time = censor_time,
    stringsAsFactors = FALSE
  )
}
