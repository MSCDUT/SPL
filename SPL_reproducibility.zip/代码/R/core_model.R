# Core mixture-cure likelihood calculations.
# Compatible with the R 3.6 runtime available in this workspace.

log1pexp <- function(x) {
  out <- numeric(length(x))
  positive <- x > 0
  out[positive] <- x[positive] + log1p(exp(-x[positive]))
  out[!positive] <- log1p(exp(x[!positive]))
  out
}

check_binary_status <- function(status) {
  if (any(is.na(status)) || any(!(status %in% c(0, 1)))) {
    stop("status must contain only 0 and 1", call. = FALSE)
  }
}

check_positive_scalar <- function(x, name) {
  if (length(x) != 1L || !is.finite(x) || x <= 0) {
    stop(sprintf("%s must be one finite positive number", name), call. = FALSE)
  }
}

baseline_loglogistic <- function(v) {
  if (any(!is.finite(v)) || any(v <= 0)) {
    stop("log-logistic baseline arguments must be finite and positive", call. = FALSE)
  }
  # Logistic(0, 1) error implies a log-logistic time with shape=scale=1.
  log_survival <- -log1p(v)
  log_hazard <- -log1p(v)
  list(log_survival = log_survival, log_hazard = log_hazard)
}

baseline_lognormal <- function(v) {
  if (any(!is.finite(v)) || any(v <= 0)) {
    stop("log-normal baseline arguments must be finite and positive", call. = FALSE)
  }
  log_v <- log(v)
  log_survival <- pnorm(log_v, lower.tail = FALSE, log.p = TRUE)
  log_density <- dnorm(log_v, log = TRUE) - log_v
  list(
    log_survival = log_survival,
    log_hazard = log_density - log_survival
  )
}

baseline_truncated_exponential <- function(v, lambda = 0.1, tau = 10) {
  check_positive_scalar(lambda, "lambda")
  check_positive_scalar(tau, "tau")
  if (any(!is.finite(v)) || any(v <= 0) || any(v >= tau)) {
    stop("truncated-exponential arguments must be finite and in (0, tau)", call. = FALSE)
  }
  end_mass <- exp(-lambda * tau)
  numerator <- exp(-lambda * v) - end_mass
  log_survival <- log(numerator) - log1p(-end_mass)
  log_hazard <- log(lambda) - lambda * v - log(numerator)
  list(log_survival = log_survival, log_hazard = log_hazard)
}

aft_mixture_loglik_contribution <- function(
    time,
    status,
    incidence_lp,
    aft_lp,
    rho_s = 1,
    rho_c = 1,
    baseline) {
  check_binary_status(status)
  check_positive_scalar(rho_s, "rho_s")
  check_positive_scalar(rho_c, "rho_c")
  n <- length(time)
  if (length(status) != n || length(incidence_lp) != n || length(aft_lp) != n) {
    stop("time, status, incidence_lp, and aft_lp must have equal lengths", call. = FALSE)
  }
  if (any(!is.finite(time)) || any(time <= 0)) {
    stop("observed times must be finite and positive", call. = FALSE)
  }

  log_rho_s <- log(rho_s)
  shifted_incidence_lp <- incidence_lp + log(rho_c)
  residual_time <- time * exp(-aft_lp - log_rho_s)
  base <- baseline(residual_time)

  if (!is.list(base) ||
      is.null(base$log_survival) ||
      is.null(base$log_hazard)) {
    stop("baseline must return log_survival and log_hazard", call. = FALSE)
  }

  event_loglik <- shifted_incidence_lp - log1pexp(shifted_incidence_lp) -
    aft_lp - log_rho_s + base$log_hazard + base$log_survival
  censored_loglik <- log1pexp(shifted_incidence_lp + base$log_survival) -
    log1pexp(shifted_incidence_lp)

  status * event_loglik + (1 - status) * censored_loglik
}

aft_mixture_log_lr <- function(
    time,
    status,
    incidence_lp,
    aft_lp,
    rho_s,
    rho_c,
    baseline,
    strict_finite = TRUE) {
  null_loglik <- aft_mixture_loglik_contribution(
    time = time,
    status = status,
    incidence_lp = incidence_lp,
    aft_lp = aft_lp,
    rho_s = 1,
    rho_c = 1,
    baseline = baseline
  )
  alternative_loglik <- aft_mixture_loglik_contribution(
    time = time,
    status = status,
    incidence_lp = incidence_lp,
    aft_lp = aft_lp,
    rho_s = rho_s,
    rho_c = rho_c,
    baseline = baseline
  )
  score <- alternative_loglik - null_loglik
  if (any(is.na(score))) {
    stop("likelihood-ratio score contains NA/NaN", call. = FALSE)
  }
  if (strict_finite && any(!is.finite(score))) {
    stop("likelihood-ratio score is non-finite; inspect support and estimation", call. = FALSE)
  }
  score
}

aft_mixture_log_lr_expanded <- function(
    time,
    status,
    incidence_lp,
    aft_lp,
    rho_s,
    rho_c,
    baseline) {
  check_binary_status(status)
  check_positive_scalar(rho_s, "rho_s")
  check_positive_scalar(rho_c, "rho_c")
  v0 <- time * exp(-aft_lp)
  v1 <- v0 / rho_s
  base0 <- baseline(v0)
  base1 <- baseline(v1)
  aft_mixture_log_lr_from_baseline_evaluations(
    status = status,
    incidence_lp = incidence_lp,
    rho_s = rho_s,
    rho_c = rho_c,
    base0 = base0,
    base1 = base1
  )
}

aft_mixture_log_lr_from_baseline_evaluations <- function(
    status,
    incidence_lp,
    rho_s,
    rho_c,
    base0,
    base1) {
  check_binary_status(status)
  check_positive_scalar(rho_s, "rho_s")
  check_positive_scalar(rho_c, "rho_c")
  if (length(incidence_lp) != length(status) || any(!is.finite(incidence_lp))) {
    stop("incidence_lp must be finite and match status", call. = FALSE)
  }
  required <- c("log_survival", "log_hazard")
  if (!is.list(base0) || !is.list(base1) ||
      !all(required %in% names(base0)) || !all(required %in% names(base1))) {
    stop("base0 and base1 must contain log_survival and log_hazard", call. = FALSE)
  }
  expected_length <- length(status)
  lengths <- c(
    length(base0$log_survival), length(base0$log_hazard),
    length(base1$log_survival), length(base1$log_hazard)
  )
  if (any(lengths != expected_length)) {
    stop("baseline evaluations must match status", call. = FALSE)
  }
  log_rho_c <- log(rho_c)

  normalization <- log1pexp(incidence_lp) -
    log1pexp(incidence_lp + log_rho_c)
  event_part <- status * (
    log_rho_c - log(rho_s) +
      base1$log_hazard - base0$log_hazard +
      base1$log_survival - base0$log_survival
  )
  censored_part <- (1 - status) * (
    log1pexp(incidence_lp + log_rho_c + base1$log_survival) -
      log1pexp(incidence_lp + base0$log_survival)
  )
  score <- normalization + event_part + censored_part
  if (any(!is.finite(score))) {
    stop("expanded likelihood-ratio score is non-finite", call. = FALSE)
  }
  score
}
