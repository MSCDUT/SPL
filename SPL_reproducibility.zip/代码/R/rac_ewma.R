# Formula-level RAC-EWMA comparator.
#
# This file reproduces the two observation-level score formulas in the
# RAC-EWMA authors' public repository. It deliberately does not fit a mixture
# cure model: all probabilities must be predictions from a model fixed using
# Phase I data only.

rac_validate_equal_vectors <- function(status,
                                       susceptibility_probability,
                                       survival_probability) {
  vectors <- list(
    status = status,
    susceptibility_probability = susceptibility_probability,
    survival_probability = survival_probability
  )
  lengths <- vapply(vectors, length, integer(1))
  if (length(unique(lengths)) != 1L || lengths[1] == 0L) {
    stop("RAC-EWMA inputs must be nonempty vectors of equal length", call. = FALSE)
  }
  if (!is.numeric(status) || any(!is.finite(status)) ||
      any(!(status %in% c(0, 1)))) {
    stop("status must contain only 0 and 1", call. = FALSE)
  }
  if (!is.numeric(susceptibility_probability) ||
      any(!is.finite(susceptibility_probability)) ||
      any(susceptibility_probability <= 0 | susceptibility_probability >= 1)) {
    stop("susceptibility_probability must be strictly between 0 and 1", call. = FALSE)
  }
  if (!is.numeric(survival_probability) ||
      any(!is.finite(survival_probability)) ||
      any(survival_probability <= 0 | survival_probability > 1)) {
    stop("survival_probability must be in (0, 1]", call. = FALSE)
  }
  invisible(TRUE)
}

rac_posterior_susceptible <- function(status,
                                      susceptibility_probability,
                                      survival_probability) {
  rac_validate_equal_vectors(
    status,
    susceptibility_probability,
    survival_probability
  )
  status + (1 - status) *
    susceptibility_probability * survival_probability /
    (1 - susceptibility_probability +
       susceptibility_probability * survival_probability)
}

rac_component_scores <- function(status,
                                 susceptibility_probability,
                                 survival_probability) {
  posterior <- rac_posterior_susceptible(
    status,
    susceptibility_probability,
    survival_probability
  )
  cumulative_hazard <- -log(survival_probability)

  # The public code calls these RACC and RACL, respectively. Although the
  # prediction field is named CURE there, its posterior expression treats the
  # latent state as susceptibility to the event.
  cure_score <- (posterior - susceptibility_probability)^2 -
    susceptibility_probability * (1 - susceptibility_probability)
  latency_score <- (posterior * (status - cumulative_hazard))^2 -
    posterior * cumulative_hazard

  data.frame(
    posterior_susceptible = posterior,
    cumulative_hazard = cumulative_hazard,
    cure_score = cure_score,
    latency_score = latency_score
  )
}

rac_ewma_components <- function(component_scores,
                                lambda_cure,
                                lambda_latency,
                                initial_cure = 0,
                                initial_latency = 0) {
  required <- c("cure_score", "latency_score")
  if (!is.data.frame(component_scores) ||
      !all(required %in% names(component_scores))) {
    stop(
      "component_scores must contain cure_score and latency_score",
      call. = FALSE
    )
  }
  data.frame(
    cure_statistic = ewma_statistic(
      component_scores$cure_score,
      lambda = lambda_cure,
      e0 = initial_cure
    ),
    latency_statistic = ewma_statistic(
      component_scores$latency_score,
      lambda = lambda_latency,
      e0 = initial_latency
    )
  )
}

rac_first_any_signal <- function(cure_statistic,
                                 latency_statistic,
                                 cure_lower = -Inf,
                                 cure_upper = Inf,
                                 latency_lower = -Inf,
                                 latency_upper = Inf) {
  if (length(cure_statistic) != length(latency_statistic) ||
      length(cure_statistic) == 0L) {
    stop("RAC-EWMA statistic vectors must be nonempty and equal in length", call. = FALSE)
  }
  cure_signal <- first_signal(cure_statistic, cure_lower, cure_upper)
  latency_signal <- first_signal(
    latency_statistic,
    latency_lower,
    latency_upper
  )
  first <- min(cure_signal, latency_signal)
  component <- if (first > length(cure_statistic)) {
    NA_character_
  } else if (cure_signal == latency_signal) {
    "both"
  } else if (cure_signal < latency_signal) {
    "cure"
  } else {
    "latency"
  }
  list(
    run_length = first,
    component = component,
    cure_run_length = cure_signal,
    latency_run_length = latency_signal,
    horizon = length(cure_statistic)
  )
}

rac_ewma_matrices <- function(cure_score_matrix,
                              latency_score_matrix,
                              lambda_cure,
                              lambda_latency,
                              initial_cure = 0,
                              initial_latency = 0) {
  if (!is.matrix(cure_score_matrix) || !is.matrix(latency_score_matrix) ||
      !identical(dim(cure_score_matrix), dim(latency_score_matrix)) ||
      any(!is.finite(cure_score_matrix)) ||
      any(!is.finite(latency_score_matrix))) {
    stop("RAC score matrices must be finite and have identical dimensions", call. = FALSE)
  }
  matrix_ewma <- function(score_matrix, lambda, initial) {
    if (length(lambda) != 1L || !is.finite(lambda) ||
        lambda <= 0 || lambda > 1) {
      stop("RAC smoothing parameters must be in (0, 1]", call. = FALSE)
    }
    if (length(initial) != 1L || !is.finite(initial)) {
      stop("RAC EWMA initial values must be finite scalars", call. = FALSE)
    }
    statistic <- matrix(0, nrow(score_matrix), ncol(score_matrix))
    previous <- rep(initial, nrow(score_matrix))
    for (column in seq_len(ncol(score_matrix))) {
      statistic[, column] <- lambda * score_matrix[, column] +
        (1 - lambda) * previous
      previous <- statistic[, column]
    }
    statistic
  }
  list(
    cure = matrix_ewma(cure_score_matrix, lambda_cure, initial_cure),
    latency = matrix_ewma(
      latency_score_matrix,
      lambda_latency,
      initial_latency
    )
  )
}

rac_combined_run_lengths <- function(cure_statistic_matrix,
                                     latency_statistic_matrix,
                                     cure_lower,
                                     cure_upper,
                                     latency_lower,
                                     latency_upper) {
  if (!is.matrix(cure_statistic_matrix) ||
      !is.matrix(latency_statistic_matrix) ||
      !identical(dim(cure_statistic_matrix), dim(latency_statistic_matrix)) ||
      nrow(cure_statistic_matrix) == 0L || ncol(cure_statistic_matrix) == 0L ||
      any(!is.finite(cure_statistic_matrix)) ||
      any(!is.finite(latency_statistic_matrix))) {
    stop("RAC statistic matrices must be finite and have identical dimensions", call. = FALSE)
  }
  limits <- c(cure_lower, cure_upper, latency_lower, latency_upper)
  if (length(limits) != 4L || any(is.na(limits)) ||
      cure_lower >= cure_upper || latency_lower >= latency_upper) {
    stop("RAC lower limits must be smaller than upper limits", call. = FALSE)
  }
  crossed <- cure_statistic_matrix < cure_lower |
    cure_statistic_matrix > cure_upper |
    latency_statistic_matrix < latency_lower |
    latency_statistic_matrix > latency_upper
  run_length <- max.col(crossed, ties.method = "first")
  no_signal <- rowSums(crossed) == 0L
  run_length[no_signal] <- ncol(crossed) + 1L
  as.integer(run_length)
}

rac_calibrate_combined_limits <- function(cure_statistic_matrix,
                                          latency_statistic_matrix,
                                          target_arl,
                                          center_cure = 0,
                                          center_latency = 0,
                                          tail_probability = 0.01,
                                          relative_tolerance = 0.01,
                                          max_iterations = 60L) {
  if (length(target_arl) != 1L || !is.finite(target_arl) || target_arl <= 1 ||
      target_arl >= ncol(cure_statistic_matrix) + 1L) {
    stop("target_arl must be between 1 and horizon plus 1", call. = FALSE)
  }
  if (length(tail_probability) != 1L || !is.finite(tail_probability) ||
      tail_probability <= 0 || tail_probability >= 0.5) {
    stop("tail_probability must be in (0, 0.5)", call. = FALSE)
  }
  if (length(relative_tolerance) != 1L || !is.finite(relative_tolerance) ||
      relative_tolerance <= 0) {
    stop("relative_tolerance must be positive", call. = FALSE)
  }
  # Validate matrices before computing empirical base distances.
  rac_combined_run_lengths(
    cure_statistic_matrix,
    latency_statistic_matrix,
    -Inf,
    Inf,
    -Inf,
    Inf
  )
  cure_quantiles <- as.numeric(stats::quantile(
    cure_statistic_matrix,
    probs = c(tail_probability, 1 - tail_probability),
    names = FALSE,
    type = 8
  ))
  latency_quantiles <- as.numeric(stats::quantile(
    latency_statistic_matrix,
    probs = c(tail_probability, 1 - tail_probability),
    names = FALSE,
    type = 8
  ))
  distances <- c(
    cure_lower = center_cure - cure_quantiles[1],
    cure_upper = cure_quantiles[2] - center_cure,
    latency_lower = center_latency - latency_quantiles[1],
    latency_upper = latency_quantiles[2] - center_latency
  )
  if (any(!is.finite(distances)) || any(distances <= 0)) {
    stop("empirical RAC tails must lie on both sides of the chart centers", call. = FALSE)
  }
  limits_at <- function(multiplier) {
    c(
      cure_lower = center_cure - multiplier * unname(distances["cure_lower"]),
      cure_upper = center_cure + multiplier * unname(distances["cure_upper"]),
      latency_lower = center_latency - multiplier * unname(distances["latency_lower"]),
      latency_upper = center_latency + multiplier * unname(distances["latency_upper"])
    )
  }
  evaluate <- function(multiplier) {
    limits <- limits_at(multiplier)
    run_lengths <- rac_combined_run_lengths(
      cure_statistic_matrix,
      latency_statistic_matrix,
      limits["cure_lower"],
      limits["cure_upper"],
      limits["latency_lower"],
      limits["latency_upper"]
    )
    list(
      multiplier = multiplier,
      limits = limits,
      run_lengths = run_lengths,
      arl = mean(run_lengths)
    )
  }

  lower <- 0
  upper <- 1
  upper_result <- evaluate(upper)
  while (upper_result$arl < target_arl && upper < 1024) {
    upper <- upper * 2
    upper_result <- evaluate(upper)
  }
  if (upper_result$arl < target_arl) {
    stop("target ARL was not bracketed within the finite horizon", call. = FALSE)
  }
  best <- upper_result
  for (iteration in seq_len(max_iterations)) {
    midpoint <- (lower + upper) / 2
    result <- evaluate(midpoint)
    if (abs(result$arl - target_arl) < abs(best$arl - target_arl)) {
      best <- result
    }
    if (result$arl < target_arl) {
      lower <- midpoint
    } else {
      upper <- midpoint
    }
    if (abs(best$arl - target_arl) / target_arl <= relative_tolerance) break
  }
  best$target_arl <- target_arl
  best$tail_probability <- tail_probability
  best$right_censoring_fraction <- mean(
    best$run_lengths == ncol(cure_statistic_matrix) + 1L
  )
  best
}
