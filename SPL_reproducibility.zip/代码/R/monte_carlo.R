# Monte Carlo helpers. Each row must be an independently generated patient stream.

ewma_matrix <- function(score_matrix, lambda = 0.069, e0 = 0) {
  if (!is.matrix(score_matrix) || !is.numeric(score_matrix) || any(!is.finite(score_matrix))) {
    stop("score_matrix must be a finite numeric matrix", call. = FALSE)
  }
  if (lambda <= 0 || lambda > 1 || !is.finite(lambda)) {
    stop("lambda must be in (0, 1]", call. = FALSE)
  }
  if (length(e0) != 1L || !is.finite(e0)) {
    stop("e0 must be one finite number", call. = FALSE)
  }
  out <- matrix(NA_real_, nrow = nrow(score_matrix), ncol = ncol(score_matrix))
  previous <- rep(e0, nrow(score_matrix))
  for (j in seq_len(ncol(score_matrix))) {
    out[, j] <- lambda * score_matrix[, j] + (1 - lambda) * previous
    previous <- out[, j]
  }
  out
}

upper_run_lengths <- function(statistic_matrix, upper) {
  if (!is.matrix(statistic_matrix) || any(!is.finite(statistic_matrix))) {
    stop("statistic_matrix must be a finite matrix", call. = FALSE)
  }
  if (length(upper) != 1L || !is.finite(upper)) {
    stop("upper must be one finite number", call. = FALSE)
  }
  horizon <- ncol(statistic_matrix)
  apply(statistic_matrix, 1, function(row) {
    crossed <- which(row > upper)
    if (length(crossed) == 0L) horizon + 1L else crossed[1]
  })
}

calibrate_upper_limit <- function(
    ic_score_matrix,
    target_arl0,
    lambda = 0.069,
    e0 = mean(ic_score_matrix),
    iterations = 60L) {
  if (!is.matrix(ic_score_matrix) || any(!is.finite(ic_score_matrix))) {
    stop("ic_score_matrix must be a finite matrix", call. = FALSE)
  }
  horizon <- ncol(ic_score_matrix)
  if (!is.finite(target_arl0) || target_arl0 <= 1 || target_arl0 > horizon + 1) {
    stop("target_arl0 must be in (1, horizon + 1]", call. = FALSE)
  }
  statistic <- ewma_matrix(ic_score_matrix, lambda = lambda, e0 = e0)
  lower <- min(statistic) - .Machine$double.eps
  upper <- max(statistic) + .Machine$double.eps

  evaluate <- function(limit) {
    mean(upper_run_lengths(statistic, limit))
  }
  for (i in seq_len(iterations)) {
    midpoint <- (lower + upper) / 2
    achieved <- evaluate(midpoint)
    if (achieved < target_arl0) {
      lower <- midpoint
    } else {
      upper <- midpoint
    }
  }
  candidates <- c(lower, upper)
  achieved <- vapply(candidates, evaluate, numeric(1))
  best <- which.min(abs(achieved - target_arl0))
  list(
    upper = candidates[best],
    achieved_arl0 = achieved[best],
    target_arl0 = target_arl0,
    lambda = lambda,
    e0 = e0,
    replicates = nrow(ic_score_matrix),
    horizon = horizon
  )
}

