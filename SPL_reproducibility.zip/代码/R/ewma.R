# EWMA mechanics kept independent of estimation and simulation.

ewma_statistic <- function(scores, lambda = 0.069, e0 = 0) {
  if (!is.numeric(scores) || any(!is.finite(scores))) {
    stop("scores must be finite numeric values", call. = FALSE)
  }
  if (length(lambda) != 1L || !is.finite(lambda) || lambda <= 0 || lambda > 1) {
    stop("lambda must be in (0, 1]", call. = FALSE)
  }
  if (length(e0) != 1L || !is.finite(e0)) {
    stop("e0 must be one finite number", call. = FALSE)
  }
  out <- numeric(length(scores))
  previous <- e0
  for (i in seq_along(scores)) {
    out[i] <- lambda * scores[i] + (1 - lambda) * previous
    previous <- out[i]
  }
  out
}

first_signal <- function(statistic, lower = -Inf, upper = Inf) {
  if (any(!is.finite(statistic))) {
    stop("statistic must be finite", call. = FALSE)
  }
  if (length(lower) != 1L || length(upper) != 1L || lower >= upper) {
    stop("lower must be smaller than upper", call. = FALSE)
  }
  crossed <- which(statistic < lower | statistic > upper)
  if (length(crossed) == 0L) return(length(statistic) + 1L)
  crossed[1]
}

