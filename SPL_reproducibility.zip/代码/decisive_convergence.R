options(warn = 1)
args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) >= 2L)
project <- normalizePath(args[1], mustWork = TRUE)
output_directory <- normalizePath(args[2], mustWork = TRUE)
if (length(args) >= 3L) .libPaths(c(args[3], .libPaths()))
suppressPackageStartupMessages(library(smcure))
stopifnot(as.character(packageVersion("smcure")) == "2.2")
cohort <- read.csv(file.path(project, "原始数据/决定性审计/phase1.csv"))
cohort <- cohort[cohort$family == "PH", , drop = FALSE]
stopifnot(nrow(cohort) == 1200L, all(cohort$seed == 62610240))
# Replay the identical retained cohort from its original seed. CSV's decimal
# roundtrip loses ulps, which can alter rank ties and the flat-coordinate path.
set.seed(62610240L)
replay_x_incidence <- rnorm(1200L)
replay_x_latency <- rbinom(1200L, 1, .5)
replay_u_cure <- runif(1200L)
replay_u_latency <- runif(1200L)
replay_u_censor <- runif(1200L)
replay_susceptible <- replay_u_cure <= plogis(-.7 * replay_x_incidence)
replay_time <- 8 * sqrt(expm1(-log(replay_u_latency) /
                            exp(.5 * replay_x_latency)))
replay_event <- ifelse(replay_susceptible, replay_time, Inf)
replay_censor <- 30.510331148872091 * replay_u_censor
replay <- data.frame(tstart = 0, tstop = pmin(replay_event, replay_censor),
 status = as.integer(replay_event <= replay_censor),
 x_incidence = replay_x_incidence, x_latency = replay_x_latency)
input_roundtrip_max_abs <- max(abs(as.matrix(cohort[, names(replay)]) -
                                  as.matrix(replay)))
stopifnot(input_roundtrip_max_abs < 1e-12,
          identical(as.integer(cohort$status), replay$status))
cohort <- replay
reference <- read.csv(file.path(project, "原始数据/决定性审计/fit_diagnostics.csv"))
reference <- reference[reference$family == "PH", , drop = FALSE]
diagnostics <- new.env(parent = emptyenv())
diagnostics$rows <- list()
diagnostics$previous_grid <- NULL
diagnostics$previous_weights <- NULL
time_grid <- exp(seq(log(min(cohort$tstop)), log(max(cohort$tstop)), length.out = 51L))

# Rebuild the exact weighted step survivor on a fixed grid of existing binary
# latency covariates. Only deterministic predictions, no generated observations.
grid_survival <- function(Time, Status, X, beta, weights) {
  residual <- drop(log(Time) - X %*% beta)
  events <- sort(unique(residual[Status == 1]))
  event_count <- tabulate(match(residual[Status == 1], events), nbins = length(events))
  risk <- vapply(events, function(value) sum(weights[residual >= value]), numeric(1))
  cumulative <- cumsum(event_count / risk)
  query <- c(log(time_grid) - beta[1], log(time_grid) - beta[1] - beta[2])
  index <- findInterval(query, events)
  value <- rep(1, length(query))
  positive <- index > 0L
  value[positive] <- exp(-cumulative[index[positive]])
  value[query > max(events)] <- 0
  value
}

record_iteration <- function(iteration, b, beta, s, w, new_b, new_beta,
                             new_s, tau, Time, Status, X, Z) {
  incidence_delta <- as.numeric(new_b - b)
  latency_delta <- as.numeric(new_beta - beta)
  survivor_delta <- as.numeric(new_s - s)
  old_p <- plogis(drop(Z %*% b))
  new_p <- plogis(drop(Z %*% new_b))
  old_population <- 1 - old_p + old_p * as.numeric(s)
  new_population <- 1 - new_p + new_p * as.numeric(new_s)
  prediction <- grid_survival(Time, Status, X, new_beta, w)
  grid_delta <- if (is.null(diagnostics$previous_grid)) NA_real_ else
    max(abs(prediction - diagnostics$previous_grid))
  weight_delta <- if (is.null(diagnostics$previous_weights)) NA_real_ else
    max(abs(w - diagnostics$previous_weights))
  components <- c(sum(incidence_delta^2), latency_delta[1]^2,
                  sum(latency_delta[-1]^2), sum(survivor_delta^2))
  stopifnot(abs(sum(components) - tau) < 1e-12)
  diagnostics$rows[[length(diagnostics$rows) + 1L]] <- data.frame(
    family = "PH", seed = 62610240L, phase1_n = 1200L,
    configured_emmax = 100L, tolerance = 1e-7, iteration = iteration,
    tau = tau, incidence_coef_sse = components[1],
    latency_intercept_squared_change = components[2],
    latency_slope_sse = components[3], conditional_survival_sse = components[4],
    incidence_max_abs_change = max(abs(incidence_delta)),
    latency_intercept_before = beta[1], latency_intercept_after = new_beta[1],
    latency_slope_before = beta[2], latency_slope_after = new_beta[2],
    susceptibility_probability_max_abs_change = max(abs(new_p - old_p)),
    conditional_survival_max_abs_change = max(abs(survivor_delta)),
    population_survival_max_abs_change = max(abs(new_population - old_population)),
    current_grid_survival_max_abs_change = grid_delta,
    posterior_weight_max_abs_change = weight_delta,
    tau_without_latency_intercept = sum(components[c(1, 3, 4)]),
    intercept_fraction_of_tau = components[2] / tau
  )
  diagnostics$previous_grid <- prediction
  diagnostics$previous_weights <- as.numeric(w)
  invisible(NULL)
}

# Add an observer after the original stopping statistic is evaluated. The
# objective, initialization, updates, loop bounds and stopping rule stay intact.
namespace <- asNamespace("smcure")
original_em <- get("em", envir = namespace)
injections <- 0L
inject_observer <- function(node) {
  if (!is.call(node)) return(node)
  if (identical(node[[1]], as.name("<-")) &&
      identical(node[[2]], as.name("convergence")) && is.call(node[[3]])) {
    injections <<- injections + 1L
    return(as.call(list(as.name("{"), node, quote(
      record_iteration(i, b, beta, s, w, update_cureb, update_beta,
                       update_s, convergence, Time, Status, X, Z)
    ))))
  }
  for (index in seq_along(node)[-1L]) node[[index]] <- inject_observer(node[[index]])
  node
}
instrumented_em <- original_em
body(instrumented_em) <- inject_observer(body(original_em))
stopifnot(injections == 1L)
observer_environment <- new.env(parent = environment(original_em))
observer_environment$record_iteration <- record_iteration
environment(instrumented_em) <- observer_environment
assignInNamespace("em", instrumented_em, ns = "smcure")
elapsed <- system.time(fit <- smcure::smcure(
  survival::Surv(tstop, status) ~ x_latency,
  cureform = ~ x_incidence, data = cohort, model = "aft",
  Var = FALSE, emmax = 100, eps = 1e-7
))["elapsed"]
assignInNamespace("em", original_em, ns = "smcure")
stopifnot(abs(fit$beta[1] - reference$aft_raw_intercept) < 1e-12,
          abs(fit$beta[2] - reference$aft_slope) < 1e-12,
          max(abs(fit$b - c(reference$incidence_intercept,
                            reference$incidence_slope))) < 1e-12)
result <- do.call(rbind, diagnostics$rows)
result$elapsed_seconds <- as.numeric(elapsed)
result$matches_original_fit <- TRUE
result$input_roundtrip_max_abs <- input_roundtrip_max_abs
write.csv(result, file.path(output_directory, "em_iterations.csv"), row.names = FALSE)
print(tail(result, 10L), row.names = FALSE)
