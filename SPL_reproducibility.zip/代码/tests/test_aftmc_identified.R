# Deterministic implementation checks; no Monte Carlo simulation.
args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) == 2L)
project <- normalizePath(args[1], mustWork = TRUE)
module <- normalizePath(args[2], mustWork = TRUE)
source(file.path(project, "代码", "R", "core_model.R"))
source(file.path(project, "代码", "R", "semiparametric_aftmc.R"))
source(module)

logtime <- c(0, 1, 2, 3, 1.3, 2.6, 3.2, 4.2)
status <- c(1, 1, 1, 0, 1, 1, 0, 0)
x <- c(0, 0, 1, 1, 0, 1, 0, 1)
w <- c(1, 1, 1, .4, 1, 1, .3, .2)
cache <- aftmc_rank_cache(logtime, status, matrix(x, ncol = 1))
rank <- aftmc_rank_update(cache, w)
# Compare exact slope to all breakpoints and an independent dense scalar grid.
objective <- function(b) aftmc_gehan_objective(b, logtime, status, matrix(x, ncol = 1), w)
target <- objective(rank$slope)
grid <- sort(unique(c(cache$breakpoint, seq(-10, 10, length.out = 2001))))
stopifnot(target <= min(vapply(grid, objective, numeric(1)))+1e-10)
# Hand-calculated objective orientation and weights delta_i*w_j.
e <- logtime-rank$slope*x
manual <- 0
for (i in seq_along(e)) for (j in seq_along(e)) {
  manual <- manual+status[i]*w[j]*max(e[j]-e[i], 0)/length(e)
}
stopifnot(abs(target-manual) < 1e-12)
# Translation never affects the rank update.
rank_shifted <- aftmc_rank_update(aftmc_rank_cache(logtime+11, status,
                                                 matrix(x, ncol = 1)), w)
stopifnot(abs(rank$slope-rank_shifted$slope) < 1e-12)

# Continuous scalar covariate: weighted kinks use |z_j-z_i|, not a binary shortcut.
continuous_x <- c(-1.2, -.7, .03, .31, .85, 1.16, 1.5, 2.05)
continuous_cache <- aftmc_rank_cache(logtime, status, matrix(continuous_x, ncol = 1))
continuous_rank <- aftmc_rank_update(continuous_cache, w)
continuous_objective <- function(b) aftmc_gehan_objective(b, logtime, status,
                                                        matrix(continuous_x, ncol = 1), w)
continuous_grid <- sort(unique(c(continuous_cache$breakpoint,
                                seq(-10, 10, length.out = 2001))))
stopifnot(continuous_objective(continuous_rank$slope) <=
            min(vapply(continuous_grid, continuous_objective, numeric(1)))+1e-10)

na <- aftmc_step_nelson_aalen(e, status, w)
na_reference <- weighted_nelson_aalen(e, status, w)
stopifnot(max(abs(as.matrix(na)-as.matrix(na_reference))) < 1e-12)
expected_S <- vapply(e, function(v) if (v > max(na$event_residual)) 0 else
  exp(-sum(na$increment[na$event_residual <= v])), numeric(1))
stopifnot(max(abs(expected_S-aftmc_step_survival(na, e))) < 1e-12)

# Proper-tail normalized route invariance of both explicit and expanded LRs.
smoother <- new_route_a_smoother(na, kernel = "gaussian")
raw <- structure(list(incidence_coef = c(-.2, -.4), latency_coef = c(0, rank$slope),
                      residual = e, nelson_aalen = na, smoother = smoother),
                 class = "route_a_aftmc")
location <- aftmc_error_mean(smoother)
centered <- aftmc_center_route(raw, location$mean)
zero <- aftmc_error_mean(centered$smoother)
stopifnot(abs(zero$mean) < 1e-6)
time <- exp(logtime)
ilp <- -.2-.4*x
base_raw <- route_a_positive_time_baseline(smoother, "boundary_complete")
base_centered <- centered$baseline
lr_raw <- aft_mixture_log_lr(time, status, ilp, rank$slope*x, .75, 1.5, base_raw)
lr_centered <- aft_mixture_log_lr(time, status, ilp,
                               centered$latency_coef[1]+rank$slope*x, .75, 1.5, base_centered)
expanded <- aft_mixture_log_lr_expanded(time, status, ilp,
                                     centered$latency_coef[1]+rank$slope*x, .75, 1.5, base_centered)
stopifnot(max(abs(lr_raw-lr_centered)) < 1e-10,
          max(abs(expanded-lr_centered)) < 1e-10)

# Deliberately impossible iteration cap must fail visibly, not return a fit.
d <- data.frame(tstop = time, status = status, x_incidence = c(-1, 1, -.5, .5, -.2, .2, .8, -.8),
                x_latency = x)
failed <- tryCatch(fit_identified_aftmc(d, control = list(maxit = 1L)),
                   aftmc_convergence_error = function(e) e)
stopifnot(inherits(failed, "aftmc_convergence_error"), nrow(failed$history) == 1L)
cat("PASS: exact slope rank minimum, weight orientation, location invariance, risk sets,\n")
cat("      inclusive jumps, proper-tail normalization, LR identity, explicit failure.\n")
