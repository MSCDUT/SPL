# RAC-EWMA public-code source record

## Scientific source

- Article: Liu R, Li Y, Huang J, et al. *RAC-EWMA: A Monitoring Scheme of
  Surgical Quality With Cure-Presenting Survival Data*. Quality and
  Reliability Engineering International. Advance online publication,
  7 May 2026.
- DOI: https://doi.org/10.1002/qre.70230
- Public repository: https://github.com/ruoyuliu30/RAC-EWMA

## Version fixed for this audit

- Repository branch inspected: `main`
- Exact commit: `50c71f278a653a9d48e89c4b9cbef1e1791bd39f`
- Commit timestamp reported by GitHub: `2025-10-29T03:15:59Z`
- Files retrieved: 20 August 2026
- Local read-only snapshot: `external/rac-ewma-official/`

The downloaded files are retained byte-for-byte. Corrections and protective
wrappers are implemented separately in `R/rac_ewma.R`; the official snapshot
is not edited.

## SHA-256 checksums

| File | SHA-256 |
|---|---|
| `RACC_for_CL.R` | `72d96b7905c26afbdc05e407522a14298819d25f3ace9711c025bfdb3bb13be1` |
| `RACC_for_shifts.R` | `59c82859345390e7b5d6c8f904ac69b8cae801b24ece00d473612fd87bf008eb` |
| `RACL_for_CL.R` | `59681849a542f56360e29c672d4b64b504b43571c46a7a5b394dddc279cbb45d` |
| `RACL_for_shifts.R` | `15093cc92baf57313dc7e07378fc51895f2985da4286d139c6f31909f5ec0880` |
| `backgrounddata.R` | `e4ebb5e6480fc842134205ee045ed775611f631ff7901d4b46013e9ec205b72d` |
| `case_WHAS.R` | `a861edf329ebcaa25a9785478bd5879555e715bacac13bb80c4e76739ea872db` |

## Local execution environment

All six files pass R's syntax parser. At the time of the audit, `MASS` and
`survival` were installed, whereas `penPHcure`, `logitnorm`, `foreach`,
`doParallel`, and `smoothHR` were not. The archived `penPHcure` dependencies and
`penPHcure` 1.0.2 were subsequently compiled in a temporary library after the
Xcode licence and a stale R Fortran-linker path were resolved without editing
the global R configuration. Its minimal fit/predict/RAC-score interface passes.
See `validation/PENPHCURE_SOURCE.md`; code-level issues independent of package
availability are documented in `RAC_EWMA_CODE_AUDIT.md`.
