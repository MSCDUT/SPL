# Build current flat, single-column LaTeX tables from the retained result CSVs.
# Rscript --vanilla build_simulation_tables.R PROJECT [TABLE_DIRECTORY]
# No simulation, parameter fitting, or calibration is performed here.
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)%in%1:2)
project <- normalizePath(args[1],mustWork=TRUE)
directory <- if(length(args)==2)args[2] else file.path(project,'文章')
if(!dir.exists(directory))dir.create(directory,recursive=TRUE)
result <- file.path(project,'原始数据','重构模拟')
s <- read.csv(file.path(result,'summary.csv'),stringsAsFactors=FALSE)
centers <- read.csv(file.path(result,'score_centers.csv'),stringsAsFactors=FALSE)
calibration <- read.csv(file.path(result,'calibration_history.csv'),stringsAsFactors=FALSE)
methods <- c('AFT_LR_EWMA','AFT_LR_CUSUM','PH_observed_LR_CUSUM','RAC_EWMA_omnibus')
families <- c('AFT','PH','neither'); components <- c('cure','latency','joint')
component_labels <- c(cure='Cure only',latency='Latency only',joint='Joint')
family_labels <- c(AFT='AFT',PH='PH',neither='Neither')
number <- function(x,digits) {
  # Consistent nearest rounding with decimal half ties rounded upward.
  factor <- 10^digits
  value <- floor(x*factor+.5+1e-8)/factor
  sprintf(paste0('%.',digits,'f'),value)
}
percent <- function(p) number(100*p,1)
one <- function(family,component,magnitude,role,method) {
  x <- s[s$family==family & s$component==component & s$magnitude==magnitude &
           s$role==role & s$method==method,]
  stopifnot(nrow(x)==1L,isTRUE(x$fap_gate_pass),
            is.finite(x$restricted_mean_delay),is.finite(x$probability))
  x
}
cell <- function(x,double=FALSE) sprintf('\\shortstack{$%s\\pm%s$%s$%s\\%%$}',
   number(x$restricted_mean_delay,2),number(x$restricted_mean_mcse,2),
   if(double)'\\\\[8pt]' else '\\\\',percent(x$probability))
row <- function(values)paste0(paste(values,collapse=' & '),' \\\\[2pt]')
start <- function(caption,label,columns,size=9,double=FALSE) c('\\begin{table}[t]','\\centering',
  if(double)'\\doublespacing',
  paste0('\\caption{',caption,'}'),paste0('\\label{',label,'}'),'\\vspace{6pt}',
  paste0('\\fontsize{',size,'}{',if(size==11)'13.6' else '11','}\\selectfont'),
  if(double)'\\doublespacing',
  '\\setlength{\\tabcolsep}{3pt}',
  '\\renewcommand{\\arraystretch}{1.15}',
  paste0('\\begin{tabular}{',columns,'}'),'\\hline','\\noalign{\\vskip 3pt}')
end <- c('\\hline','\\end{tabular}','\\end{table}','')
headers <- c('\\shortstack{AFT LR\\\\EWMA}',
             '\\shortstack{Same LR\\\\CUSUM}',
             '\\shortstack{PH LR\\\\CUSUM}',
             '\\shortstack{RAC--EWMA\\\\(adaptation)}')

# A compact joint-change table is the sole performance table in the main text.
main <- start(paste0('Joint deterioration: restricted mean delay ',
  '$E[\\min(T,201)]\\pm\\mathrm{MCSE}$, with detection by 200 (\\%) below. ',
  'Each row uses 2,000 paired streams; all charts target ',
  '$P_0(T\\le200)=0.10$. Family-specific shifts and the omnibus ',
  'RAC--EWMA adaptation are defined in the text.'),
  'tab:joint','lcccc',size=11,double=TRUE)
headers_main <- c('\\shortstack{AFT LR\\\\[8pt]EWMA}',
  '\\shortstack{Same LR\\\\[8pt]CUSUM}',
  '\\shortstack{PH LR\\\\[8pt]CUSUM}',
  '\\shortstack{RAC--EWMA\\\\[8pt](adaptation)}')
main <- c(main,
          row(c('True family',headers_main)),'\\hline','\\noalign{\\vskip 3pt}')
for(family in families) {
  cells <- vapply(methods,function(method)cell(one(family,'joint',1,'OC',method),double=TRUE),character(1))
  main <- c(main,row(c(family_labels[family],cells)))
}
main <- c(main,end)

# Primary IC comparison: 27 directional designs plus three omnibus calibrations.
ic_rows <- s[s$role=='IC' & s$method%in%methods,]
ic_range <- range(ic_rows$probability)
primary_calibration <- calibration[
  !grepl('RACure_author_score_CUSUM',calibration$chart,fixed=TRUE),]
stopifnot(nrow(primary_calibration)==30L,all(primary_calibration$passed),
          all(primary_calibration$attempt==0),all(!primary_calibration$oc_seen))
ic <- start(paste0('Independent in-control FAPs (\\%), target ',
  '$P_0(T\\le200)=0.10$, from 5,000 fresh streams per entry. ',
  'All 30 primary calibrations passed without recalibration; the omnibus ',
  'RAC--EWMA calibration is shared by all components within a family. ',
  'The primary FAP range is ',number(100*ic_range[1],2),'--',
  number(100*ic_range[2],2),'\\%. The nine supplementary author-score ',
  'calibrations are separate.'),'tab:simulation-ic','llrrrr')
ic <- c(ic,row(c('True family','Design',headers)),'\\hline','\\noalign{\\vskip 3pt}')
for(family in families) for(component in components) {
  cells <- vapply(methods,function(method)
    number(100*one(family,component,0,'IC',method)$probability,2),character(1))
  ic <- c(ic,row(c(family_labels[family],component_labels[component],cells)))
}
ic <- c(ic,end)

primary <- start(paste0('Design-scale changes ($m=1$), 2,000 paired streams ',
  'per row. Entries give restricted mean delay $\\pm$ MCSE above and detection ',
  'by 200 (\\%) below. Susceptibility odds increase by 1.5; active latency ',
  'changes multiply AFT time by 0.75 or raise PH/neither susceptible survival ',
  'to power 1.5. Directional charts know the designed component, direction ',
  'and magnitude. RAC--EWMA is the omnibus adaptation.'),
  'tab:simulation-primary','llcccc')
primary <- c(primary,row(c('True family','Change',headers)),'\\hline',
             '\\noalign{\\vskip 3pt}')
for(family in families) for(component in components) {
  cells <- vapply(methods,function(method)cell(one(family,component,1,'OC',method)),character(1))
  primary <- c(primary,row(c(family_labels[family],component_labels[component],cells)))
}
primary <- c(primary,end)

magnitude <- start(paste0('AFT change-magnitude misspecification, 2,000 paired ',
  'streams per row. The true log-change vector is $m\\Delta_0$; directional ',
  'designs remain fixed at $\\Delta_0$. Entries have the meaning in ',
  'Table~\\ref{tab:simulation-primary}. Matched $m=1$ rows appear there. ',
  'Together these two tables report all 15 out-of-control cells.'),
  'tab:simulation-magnitude','llcccc')
magnitude <- c(magnitude,row(c('Change','$m$',headers)),'\\hline',
               '\\noalign{\\vskip 3pt}')
for(component in components) for(multiplier in c(.5,1.5)) {
  cells <- vapply(methods,function(method)cell(one('AFT',component,multiplier,'OC',method)),character(1))
  magnitude <- c(magnitude,row(c(component_labels[component],sprintf('%.1f',multiplier),cells)))
}
magnitude <- c(magnitude,end)

author <- start(paste0("Supplementary patient-level RACure--CUSUM author-score ",
  'adaptation, joint changes, 2,000 OC streams per row. IC means and FAPs ',
  'use the retained separate IC samples. IC alarm mean conditions on alarm ',
  'by 200; OC delay is $E[\\min(T,201)]$. Positive IC score drift and late ',
  'IC alarms distinguish this finite-episode adaptation from full PH LR. ',
  'No published-method inferiority claim is made.'),
  'tab:author-adaptation','lrrrrr')
author <- c(author,row(c('True family','\\shortstack{IC score\\\\mean}',
  '\\shortstack{IC FAP\\\\(\\%)}','\\shortstack{IC alarm\\\\mean}',
  '\\shortstack{OC DR\\\\(\\%)}','\\shortstack{OC delay\\\\$\\pm$ MCSE}')),'\\hline',
  '\\noalign{\\vskip 3pt}')
for(family in families) {
  ic_row <- one(family,'joint',0,'IC','RACure_author_score_CUSUM')
  oc_row <- one(family,'joint',1,'OC','RACure_author_score_CUSUM')
  mean_score <- centers$mean[centers$family==family & centers$score=='author_joint']
  stopifnot(length(mean_score)==1L)
  author <- c(author,row(c(family_labels[family],number(mean_score,4),
    number(100*ic_row$probability,2),number(ic_row$detected_only_mean,2),
    number(100*oc_row$probability,2),
    sprintf('$%s\\pm%s$',number(oc_row$restricted_mean_delay,2),number(oc_row$restricted_mean_mcse,2)))))
}
author <- c(author,end)
provenance <- '% Generated from retained CSVs by 代码/build_simulation_tables.R; no simulations.'
main_source <- file.path(project,'文章','manuscript.tex')
if(file.exists(main_source) && normalizePath(directory)==normalizePath(dirname(main_source))) {
  # Mechanical refresh of the one current inline table; no document copy.
  text <- readLines(main_source,warn=FALSE,encoding='UTF-8')
  first <- which(text=='% BEGIN GENERATED MAIN TABLE')
  last <- which(text=='% END GENERATED MAIN TABLE')
  stopifnot(length(first)==1L,length(last)==1L,last>first)
  current <- c(text[seq_len(first)],provenance,main,text[last:length(text)])
  writeLines(current,main_source,useBytes=TRUE)
} else {
  writeLines(c(provenance,main),file.path(directory,'simulation_main_table.tex'),useBytes=TRUE)
}
writeLines(c(provenance,ic,primary,magnitude),
           file.path(directory,'simulation_detail_tables.tex'),useBytes=TRUE)
writeLines(c(provenance,author),file.path(directory,'author_adaptation_table.tex'),useBytes=TRUE)
cat('Current flat single-column tables generated in',normalizePath(directory),'\n')
