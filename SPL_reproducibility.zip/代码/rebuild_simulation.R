# Current fixed-protocol conditional-fit simulation for the rebuilt manuscript.
# Rscript --vanilla rebuild_simulation.R PROJECT OUTPUT LOCAL_R_LIBRARY
# Original clinical data and manuscript are never changed by this program.
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==3L)
project <- normalizePath(args[1],mustWork=TRUE)
output <- normalizePath(args[2],mustWork=TRUE)
.libPaths(c(normalizePath(args[3],mustWork=TRUE),.libPaths()))
options(stringsAsFactors=FALSE,warn=1)
stopifnot(as.character(utils::packageVersion('penPHcure'))=='1.0.2')
for(f in c('core_model.R','ewma.R','monte_carlo.R','semiparametric_aftmc.R',
           'rac_ewma.R','rac_penphcure_adapter.R','m4_shared_misspec_simulation.R',
           'aftmc_identified.R')) source(file.path(project,'代码','R',f))
started <- Sys.time()
RNGkind('Mersenne-Twister','Inversion','Rejection')
phase1_n <- 1200L
calibration_n <- 5000L
validation_n <- 5000L
oc_n <- 2000L
batch_n <- 250L
horizon <- 200L
alpha <- .10
fap_absolute_tolerance <- .015
max_ic_recalibrations <- 2L
lambda <- .069
master_seed <- 62610040L
components <- c('cure','latency','joint')
families <- c('AFT','PH','neither')
methods <- c('AFT_LR_EWMA','AFT_LR_CUSUM','PH_observed_LR_CUSUM',
             'RACure_author_score_CUSUM','RAC_EWMA_omnibus')
log_or0 <- log(1.5)
log_time0 <- log(.75)
log_hr0 <- log(1.5)
lookup_score_tolerance <- 1e-4
lookup_grid_n <- 65537L
aft_censor_upper <- m4_calibrate_censor_upper(sigma0=.8,sigma1=.8)
neither_event_probability <- function(upper) {
  normal <- integrate(function(t)pnorm((log(t)-log(8))/.65),0,upper,
                      rel.tol=1e-9)$value/upper
  logistic <- integrate(function(t)plogis((log(t)-log(8)+.35)/.70),0,upper,
                        rel.tol=1e-9)$value/upper
  mean(c(normal,logistic))
}
neither_censor_upper <- uniroot(function(upper)
   .5*neither_event_probability(upper)-.35,c(1,300),tol=1e-9)$root

design <- function(component,magnitude=1) {
  c(OR=exp(if(component=='latency')0 else magnitude*log_or0),
    time=exp(if(component=='cure')0 else magnitude*log_time0),
    HR=exp(if(component=='cure')0 else magnitude*log_hr0))
}
generate <- function(family,n,seed,component='joint',magnitude=0) {
  shift <- design(component,magnitude)
  set.seed(seed)
  x_incidence <- rnorm(n); x_latency <- rbinom(n,1,.5)
  u_cure <- runif(n); u_latency <- runif(n); u_censor <- runif(n)
  incidence <- -.7*x_incidence
  if(family=='neither') incidence <- .079099272918428+incidence+.45*(x_incidence^2-1)
  susceptible <- u_cure<=plogis(incidence+log(shift['OR']))
  if(family=='AFT') {
    susceptible_time <- exp(log(8)-.35*x_latency+.8*qnorm(u_latency))*shift['time']
    upper <- aft_censor_upper
  } else if(family=='PH') {
    susceptible_time <- 8*sqrt(expm1(-log(u_latency)/(exp(.5*x_latency)*shift['HR'])))
    upper <- 30.510331148872091
  } else if(family=='neither') {
    # These covariate-specific families cannot share one AFT error law and
    # their hazard ratio varies with t. OC changes both survivor functions
    # by a common power; it is not the proposed working time-scale change.
    survivor_uniform <- u_latency^(1/shift['HR'])
    susceptible_time <- ifelse(x_latency==0,
      exp(log(8)+.65*qnorm(1-survivor_uniform)),
      exp(log(8)-.35)*((1/survivor_uniform)-1)^.70)
    upper <- neither_censor_upper
  } else stop('Unknown family')
  event <- ifelse(susceptible,susceptible_time,Inf)
  censor <- upper*u_censor
  data.frame(tstart=0,tstop=pmin(event,censor),status=as.integer(event<=censor),
             x_incidence=x_incidence,x_latency=x_latency)
}
wilson <- function(k,n) {
  z <- qnorm(.975); p <- k/n; d <- 1+z*z/n
  middle <- (p+z*z/(2*n))/d
  radius <- z*sqrt(p*(1-p)/n+z*z/(4*n*n))/d
  c(middle-radius,middle+radius)
}
summary_rl <- function(x) {
  detected <- x<=horizon; probability <- mean(detected)
  ci <- wilson(sum(detected),length(x))
  c(probability=probability,probability_mcse=sqrt(probability*(1-probability)/length(x)),
    probability_ci_low=ci[1],probability_ci_high=ci[2],
    restricted_mean_delay=mean(x),restricted_mean_mcse=sd(x)/sqrt(length(x)),
    detected_only_mean=if(any(detected))mean(x[detected]) else NA_real_,
    no_detection_fraction=mean(!detected),replicates=length(x))
}

# Interpolate only inside the observed event-residual interval. The two
# completed tails are evaluated analytically, not extrapolated/interpolated.
make_lookup <- function(route) {
  smoother <- route$smoother
  knots <- seq(smoother$event_range[1],smoother$event_range[2],length.out=lookup_grid_n)
  exact <- evaluate_route_a_log_error(smoother,knots,'boundary_complete',chunk_size=2048L)
  logS <- approxfun(knots,exact$log_survival,rule=2,ties='ordered')
  logh <- approxfun(knots,exact$log_hazard,rule=2,ties='ordered')
  boundary <- evaluate_route_a_log_error(smoother,smoother$event_range,'boundary_complete')
  H <- -boundary$log_survival; h <- exp(boundary$log_hazard)
  evaluator <- function(v) {
    stopifnot(all(is.finite(v)),all(v>0))
    r <- log(v); s <- logS(r); lh <- logh(r)
    below <- r<smoother$event_range[1]; above <- r>smoother$event_range[2]
    if(any(below)) {
      delta <- r[below]-smoother$event_range[1]; rate <- h[1]/H[1]
      s[below] <- -H[1]*exp(rate*delta)
      lh[below] <- boundary$log_hazard[1]+rate*delta
    }
    if(any(above)) {
      s[above] <- -H[2]-h[2]*(r[above]-smoother$event_range[2])
      lh[above] <- boundary$log_hazard[2]
    }
    list(log_survival=s,log_hazard=lh-r)
  }
  list(baseline=evaluator,knots=knots,log_survival=exact$log_survival,
       log_hazard=exact$log_hazard)
}
score_aft <- function(d,route,baseline,component) {
  shift <- design(component)
  eta <- route$incidence_coef[1]+route$incidence_coef[2]*d$x_incidence
  mu <- route$latency_coef[1]+route$latency_coef[2]*d$x_latency
  aft_mixture_log_lr_expanded(d$tstop,d$status,eta,mu,shift['time'],shift['OR'],baseline)
}
predict_ph_fixed <- function(fit,d) {
  # Exact specialization of penPHcure 1.0.2 predict for one tstart=0 record
  # per patient and the two fixed model formulas. No interpolation is used.
  stopifnot(all(d$tstart==0),inherits(fit,'PHcure'),length(fit$b)==2L,length(fit$beta)==1L)
  cumhaz <- fit$cumhaz; times <- attr(cumhaz,'time')
  index <- findInterval(d$tstop,times)
  H0 <- c(0,as.numeric(cumhaz))[index+1L]
  eta <- fit$b[1]+fit$b[2]*d$x_incidence
  data.frame(susceptibility_probability=plogis(eta),
    survival_probability=exp(-H0*exp(fit$beta[1]*d$x_latency)))
}
ph_observed_log_lr <- function(status,eta,H,OR,HR) {
  log1pexp(eta)-log1pexp(eta+log(OR))+
    status*(log(OR)+log(HR)-(HR-1)*H)+
    (1-status)*(log1pexp(eta+log(OR)-HR*H)-log1pexp(eta-H))
}
# Independent tiny event/censor benchmark uses direct probabilities/densities.
for(component in components) {
  eta <- c(-1,.4,1); H <- c(.1,.7,1.8); status <- c(1,0,1)
  shift <- design(component); p0 <- plogis(eta); p1 <- plogis(eta+log(shift['OR']))
  h0 <- c(.2,.4,.1); S0 <- exp(-H); S1 <- exp(-shift['HR']*H)
  f0 <- ifelse(status==1,p0*h0*S0,1-p0+p0*S0)
  f1 <- ifelse(status==1,p1*shift['HR']*h0*S1,1-p1+p1*S1)
  stopifnot(max(abs(ph_observed_log_lr(status,eta,H,shift['OR'],shift['HR'])-
                     log(f1/f0)))<1e-12)
}
score_all <- function(d,route,lookup,ph_fit) {
  pred <- predict_ph_fixed(ph_fit,d)
  comp <- rac_component_scores(d$status,pred$susceptibility_probability,pred$survival_probability)
  p <- pred$susceptibility_probability
  eta <- qlogis(p); H <- comp$cumulative_hazard
  result <- list(RAC_cure=comp$cure_score,RAC_latency=comp$latency_score)
  for(component in components) {
    shift <- design(component); OR <- shift['OR']; HR <- shift['HR']
    observed <- ph_observed_log_lr(d$status,eta,H,OR,HR)
    author <- comp$posterior_susceptible*(log(OR)+d$status*log(HR)-(HR-1)*H)
    result[[paste0('AFT_',component)]] <- score_aft(d,route,lookup$baseline,component)
    result[[paste0('PH_',component)]] <- observed
    result[[paste0('author_',component)]] <- author
  }
  stopifnot(all(vapply(result,function(v)all(is.finite(v)),logical(1))))
  result
}
chart_keys <- function() {
  c(unlist(lapply(components,function(component)
      paste(c('AFT_LR_EWMA','AFT_LR_CUSUM','PH_observed_LR_CUSUM',
              'RACure_author_score_CUSUM'),component,sep=':'))),
    'RAC_EWMA_omnibus:omnibus')
}
chart_statistics <- function(scores,n,centers,distances,limits=NULL,paths=FALSE) {
  matrices <- lapply(scores,matrix,nrow=n,ncol=horizon,byrow=TRUE)
  stats <- list()
  cumsum_stat <- function(s) {
    value <- numeric(n); out <- matrix(0,n,horizon)
    for(j in seq_len(horizon)) {value <- pmax(0,value+s[,j]);out[,j] <- value}
    out
  }
  for(component in components) {
    lr <- matrices[[paste0('AFT_',component)]]
    stats[[paste('AFT_LR_EWMA',component,sep=':')]] <-
      ewma_matrix(lr,lambda,centers[[paste0('AFT_',component)]])
    stats[[paste('AFT_LR_CUSUM',component,sep=':')]] <- cumsum_stat(lr)
    stats[[paste('PH_observed_LR_CUSUM',component,sep=':')]] <-
      cumsum_stat(matrices[[paste0('PH_',component)]])
    stats[[paste('RACure_author_score_CUSUM',component,sep=':')]] <-
      cumsum_stat(matrices[[paste0('author_',component)]])
  }
  rac <- rac_ewma_matrices(matrices$RAC_cure,matrices$RAC_latency,lambda,lambda,
                           centers$RAC_cure,centers$RAC_latency)
  stats[['RAC_EWMA_omnibus:omnibus']] <- pmax(
    (centers$RAC_cure-rac$cure)/distances[1],(rac$cure-centers$RAC_cure)/distances[2],
    (centers$RAC_latency-rac$latency)/distances[3],(rac$latency-centers$RAC_latency)/distances[4])
  maxima <- lapply(stats,function(m)apply(m,1,max))
  rls <- if(is.null(limits))NULL else lapply(names(stats),function(key)
     upper_run_lengths(stats[[key]],limits[[key]]))
  if(!is.null(rls)) names(rls) <- names(stats)
  if(!is.null(limits)) {
    multiplier <- limits[['RAC_EWMA_omnibus:omnibus']]
    independent <- rac_combined_run_lengths(rac$cure,rac$latency,
       centers$RAC_cure-multiplier*distances[1],centers$RAC_cure+multiplier*distances[2],
       centers$RAC_latency-multiplier*distances[3],centers$RAC_latency+multiplier*distances[4])
    stopifnot(identical(as.integer(rls[['RAC_EWMA_omnibus:omnibus']]),independent))
  }
  list(maxima=maxima,rls=rls,stats=if(paths)stats else NULL)
}
stream_batch <- function(family,n,seed,component,magnitude,route,lookup,ph_fit,
                         centers,distances,limits=NULL) {
  accumulated_max <- lapply(chart_keys(),function(k)numeric());names(accumulated_max) <- chart_keys()
  accumulated_rl <- if(is.null(limits))NULL else accumulated_max
  for(batch in seq_len(ceiling(n/batch_n))) {
    count <- min(batch_n,n-(batch-1L)*batch_n)
    d <- generate(family,count*horizon,seed+batch,component,magnitude)
    scores <- score_all(d,route,lookup,ph_fit)
    computed <- chart_statistics(scores,count,centers,distances,limits)
    for(key in names(accumulated_max)) {
      accumulated_max[[key]] <- c(accumulated_max[[key]],computed$maxima[[key]])
      if(!is.null(limits)) accumulated_rl[[key]] <- c(accumulated_rl[[key]],computed$rls[[key]])
    }
  }
  list(maxima=accumulated_max,rls=accumulated_rl)
}
calibrate <- function(maxima) {
  lapply(maxima,function(x) {
    h <- as.numeric(quantile(x,1-alpha,type=1))
    h+1e-10*max(1,abs(h))
  })
}
gate_ic <- function(x,cal_n) {
  p <- mean(x<=horizon)
  # Account for finite calibration as well as final validation uncertainty.
  z <- abs(p-alpha)/sqrt(alpha*(1-alpha)*(1/length(x)+1/cal_n))
  abs(p-alpha)<=fap_absolute_tolerance && z<=qnorm(.995)
}

summary_rows <- list(); raw_rows <- list(); fit_rows <- list(); cal_rows <- list()
limit_rows <- list(); mean_rows <- list(); lookup_rows <- list(); pair_rows <- list()
phase1_rows <- list(); numerical_rows <- list(); warning_rows <- list()
ph_check_rows <- list()
add_summary <- function(family,component,magnitude,role,rls,gate,seed) {
  for(method in methods) {
    key <- paste(method,if(method=='RAC_EWMA_omnibus')'omnibus' else component,sep=':')
    x <- rls[[key]]
    summary_rows[[length(summary_rows)+1L]] <<- data.frame(family,component,magnitude,role,
      method,as.list(summary_rl(x)),fap_gate_pass=gate[[key]],seed,horizon,alpha,lambda)
    raw_rows[[length(raw_rows)+1L]] <<- data.frame(family,component,magnitude,role,
      method,stream=seq_along(x),run_length=x,observed_alarm=x<=horizon,seed,
      batch_size=batch_n)
  }
}
checkpoint <- function() {
  objects <- list(summary=summary_rows,run_lengths=raw_rows,fit_diagnostics=fit_rows,
    calibration_history=cal_rows,control_limits=limit_rows,score_centers=mean_rows,
    lookup_checks=lookup_rows,paired_comparisons=pair_rows,phase1=phase1_rows,
    numerical_checks=numerical_rows,fit_warnings=warning_rows,
    ph_prediction_checks=ph_check_rows)
  for(name in names(objects)) if(length(objects[[name]])) {
    write.csv(do.call(rbind,objects[[name]]),file.path(output,paste0(name,'.csv')),row.names=FALSE)
  } else if(name=='fit_warnings') {
    write.csv(data.frame(family=character(),warning=character()),
              file.path(output,'fit_warnings.csv'),row.names=FALSE)
  }
}

for(index in seq_along(families)) {
  family <- families[index]; seed <- master_seed+100L*index
  cat(format(Sys.time()),': fitting identified model for',family,'\n');flush.console()
  phase1 <- generate(family,phase1_n,seed)
  phase1_rows[[index]] <- data.frame(family,seed,phase1)
  route <- fit_identified_aftmc(phase1,control=list(maxit=500L,coef_tol=1e-5,
                   survivor_tol=1e-5,kernel='gaussian',bandwidth_multiplier=1))
  stopifnot(isTRUE(route$diagnostics$converged))
  warnings <- character()
  ph_fit <- withCallingHandlers(fit_rac_penphcure(
    survival::Surv(tstart,tstop,status)~x_latency,~x_incidence,phase1,
    standardize=FALSE,ties='breslow',constraint=TRUE),warning=function(w) {
      warnings <<- c(warnings,conditionMessage(w));invokeRestart('muffleWarning')
    })
  stopifnot(ph_fit$converged==1L,ph_fit$iter<500L,
    all(is.finite(c(ph_fit$b,ph_fit$beta,ph_fit$cumhaz))),
    all(diff(as.numeric(ph_fit$cumhaz))>=0))
  if(length(warnings)) warning_rows[[length(warning_rows)+1L]] <-
    data.frame(family,warning=warnings)
  fit_rows[[index]] <- data.frame(family,seed,phase1_n,event_fraction=mean(phase1$status),
    incidence_intercept=route$incidence_coef[1],incidence_slope=route$incidence_coef[2],
    latency_intercept=route$latency_coef[1],latency_slope=route$latency_coef[2],
    converged=route$diagnostics$converged,iterations=route$diagnostics$iterations,
    coefficient_change=route$diagnostics$coef_change,
    survivor_change=route$diagnostics$survivor_change,
    mixture_survivor_change=route$diagnostics$mixture_survivor_change,
    rank_certificate=route$diagnostics$rank_certificate,
    mean_after_centering=route$diagnostics$mean_after_centering,
    mean_integration_error=route$diagnostics$mean_integration_error,
    ph_warning_count=length(warnings),ph_converged=ph_fit$converged,
    ph_iterations=ph_fit$iter,boundary_tail_policy='boundary_complete')
  saveRDS(list(phase1=phase1,identified_aft=route,ph_fit=ph_fit,seed=seed),
          file.path(output,paste0('phase1_fit_',family,'.rds')),version=3)
  write.csv(route$diagnostics$history,file.path(output,paste0('fit_history_',family,'.csv')),
            row.names=FALSE)
  lookup <- make_lookup(route)
  test <- generate(family,5000L,seed+2000L)
  ph_test <- rbind(phase1,test)
  ph_official <- predict_rac_penphcure(ph_fit,ph_test)
  ph_fast <- predict_ph_fixed(ph_fit,ph_test)
  ph_error <- max(abs(as.matrix(ph_official)-as.matrix(ph_fast)))
  stopifnot(ph_error<=1e-10)
  ph_check_rows[[index]] <- data.frame(family,n=nrow(ph_test),
    maximum_absolute_prediction_error=ph_error,tolerance=1e-10,
    include_exact_event_times=TRUE,official_package='penPHcure 1.0.2')
  for(component in components) {
    exact_score <- score_aft(test,route,route_a_positive_time_baseline(route$smoother,
                               'boundary_complete'),component)
    approx_score <- score_aft(test,route,lookup$baseline,component)
    error <- max(abs(exact_score-approx_score))
    stopifnot(error<=lookup_score_tolerance)
    lookup_rows[[length(lookup_rows)+1L]] <- data.frame(family,component,
        validation_n=nrow(test),grid_n=lookup_grid_n,max_abs_log_lr_error=error,
        tolerance=lookup_score_tolerance,tail_rule='exact_analytic')
  }
  center_data <- generate(family,20000L,seed+3000L)
  center_scores <- score_all(center_data,route,lookup,ph_fit)
  centers <- lapply(center_scores,mean)
  for(name in names(centers)) mean_rows[[length(mean_rows)+1L]] <-
    data.frame(family,score=name,mean=centers[[name]],mcse=sd(center_scores[[name]])/sqrt(20000),
               n=20000,seed=seed+3000L)
  # RAC boundary geometry is fixed on independent IC-only pilot streams;
  # the overall simultaneous FAP is then calibrated on 5,000 other streams.
  shape_data <- generate(family,1000L*horizon,seed+4000L)
  shape <- score_all(shape_data,route,lookup,ph_fit)
  rac <- rac_ewma_matrices(matrix(shape$RAC_cure,1000L,horizon,byrow=TRUE),
    matrix(shape$RAC_latency,1000L,horizon,byrow=TRUE),lambda,lambda,
    centers$RAC_cure,centers$RAC_latency)
  q_cure <- quantile(rac$cure,c(.01,.99),type=8)
  q_latency <- quantile(rac$latency,c(.01,.99),type=8)
  distances <- c(centers$RAC_cure-q_cure[1],q_cure[2]-centers$RAC_cure,
                 centers$RAC_latency-q_latency[1],q_latency[2]-centers$RAC_latency)
  stopifnot(all(is.finite(distances)),all(distances>0))
  rm(center_data,center_scores,shape_data,shape,rac);gc(FALSE)
  cat(format(Sys.time()),': calibration for',family,'\n');flush.console()
  calibration <- stream_batch(family,calibration_n,seed+100000L,'joint',0,
    route,lookup,ph_fit,centers,distances)
  cal_max <- calibration$maxima
  limit <- calibrate(cal_max)
  final <- NULL; final_gate <- NULL; final_seed <- NA_integer_
  for(attempt in 0:max_ic_recalibrations) {
    final_seed <- seed+200000L+attempt*10000L
    final <- stream_batch(family,validation_n,final_seed,'joint',0,
      route,lookup,ph_fit,centers,distances,limit)
    final_gate <- lapply(final$rls,gate_ic,cal_n=length(cal_max[[1]]))
    for(key in names(final$rls)) {
      x <- final$rls[[key]]; ci <- wilson(sum(x<=horizon),length(x))
      cal_rows[[length(cal_rows)+1L]] <- data.frame(family,chart=key,attempt,
        threshold=limit[[key]],calibration_n=length(cal_max[[key]]),validation_n=length(x),
        calibration_fap=mean(cal_max[[key]]>limit[[key]]),
        independent_ic_fap=mean(x<=horizon),ic_ci_low=ci[1],ic_ci_high=ci[2],
        passed=final_gate[[key]],seed=final_seed,
        absolute_tolerance=fap_absolute_tolerance,oc_seen=FALSE)
    }
    if(all(unlist(final_gate)) || attempt==max_ic_recalibrations) break
    # The failed validation sample becomes additional IC calibration only;
    # the next check is a fresh independent 5,000-stream sample. No OC is used.
    cal_max <- Map(c,cal_max,final$maxima)
    limit <- calibrate(cal_max)
  }
  for(key in names(limit)) limit_rows[[length(limit_rows)+1L]] <- data.frame(
    family,chart=key,threshold=limit[[key]],calibration_n=length(cal_max[[key]]),
    final_validation_seed=final_seed,fap_gate_pass=final_gate[[key]],
    initial_score_mean=if(startsWith(key,'AFT_LR_EWMA:'))centers[[paste0('AFT_',
      sub('.*:','',key))]] else NA_real_,
    RAC_cure_lower=if(key=='RAC_EWMA_omnibus:omnibus')centers$RAC_cure-limit[[key]]*distances[1] else NA,
    RAC_cure_upper=if(key=='RAC_EWMA_omnibus:omnibus')centers$RAC_cure+limit[[key]]*distances[2] else NA,
    RAC_latency_lower=if(key=='RAC_EWMA_omnibus:omnibus')centers$RAC_latency-limit[[key]]*distances[3] else NA,
    RAC_latency_upper=if(key=='RAC_EWMA_omnibus:omnibus')centers$RAC_latency+limit[[key]]*distances[4] else NA)
  for(component in components) add_summary(family,component,0,'IC',final$rls,
                                         final_gate,final_seed)
  checkpoint()
  # Fixed-grid numerical score approximation is checked against direct
  # kernel evaluation, including its effect on representative alarm times.
  direct_baseline <- route_a_positive_time_baseline(route$smoother,'boundary_complete')
  for(component in components) {
    d <- generate(family,20L*horizon,seed+5000L+match(component,components),component,1)
    approx_scores <- score_all(d,route,lookup,ph_fit)
    exact_scores <- approx_scores
    for(check_component in components)
      exact_scores[[paste0('AFT_',check_component)]] <- score_aft(d,route,direct_baseline,check_component)
    a <- chart_statistics(approx_scores,20L,centers,distances,limit,paths=TRUE)
    b <- chart_statistics(exact_scores,20L,centers,distances,limit,paths=TRUE)
    for(method in c('AFT_LR_EWMA','AFT_LR_CUSUM')) {
      key <- paste(method,component,sep=':')
      differences <- sum(a$rls[[key]]!=b$rls[[key]])
      stopifnot(differences==0L)
      numerical_rows[[length(numerical_rows)+1L]] <- data.frame(family,component,
        method,streams=20L,horizon,max_statistic_difference=max(abs(a$stats[[key]]-b$stats[[key]])),
        alarm_time_differences=differences,seed=seed+5000L+match(component,components))
    }
  }
  magnitudes <- if(family=='AFT')c(.5,1,1.5) else 1
  for(component in components) for(magnitude in magnitudes) {
    scenario_index <- (match(component,components)-1L)*3L+match(magnitude,c(.5,1,1.5))
    oc_seed <- seed+300000L+1000L*scenario_index
    cat(format(Sys.time()),': OC',family,component,'magnitude',magnitude,'\n');flush.console()
    oc <- stream_batch(family,oc_n,oc_seed,component,magnitude,route,lookup,ph_fit,
                       centers,distances,limit)
    add_summary(family,component,magnitude,'OC',oc$rls,final_gate,oc_seed)
    selected <- lapply(methods,function(method)oc$rls[[paste(method,
      if(method=='RAC_EWMA_omnibus')'omnibus' else component,sep=':')]])
    names(selected) <- methods
    for(pair in combn(methods,2,simplify=FALSE)) {
      difference <- selected[[pair[1]]]-selected[[pair[2]]]
      k1 <- paste(pair[1],if(pair[1]=='RAC_EWMA_omnibus')'omnibus' else component,sep=':')
      k2 <- paste(pair[2],if(pair[2]=='RAC_EWMA_omnibus')'omnibus' else component,sep=':')
      pair_rows[[length(pair_rows)+1L]] <- data.frame(family,component,magnitude,
        method_1=pair[1],method_2=pair[2],restricted_delay_difference=mean(difference),
        paired_mcse=sd(difference)/sqrt(length(difference)),
        difference_ci_low=mean(difference)-qnorm(.975)*sd(difference)/sqrt(length(difference)),
        difference_ci_high=mean(difference)+qnorm(.975)*sd(difference)/sqrt(length(difference)),
        both_fap_gates_pass=final_gate[[k1]]&&final_gate[[k2]],replicates=oc_n,seed=oc_seed)
    }
    checkpoint()
  }
}
protocol <- data.frame(item=c('phase1_n','calibration_n_initial','validation_n_per_attempt',
  'oc_n_per_cell','horizon','alpha','lambda','master_seed','fap_absolute_tolerance',
  'max_ic_recalibrations','lookup_grid_n','lookup_score_tolerance','design_log_OR',
  'design_log_time','design_log_HR','change_onset','rank_fitting','normalization',
    'outer_phase1_replicates','finite_delay_metric','phase2_fit_used','knowledge_scope',
    'neither_latency_mechanism','neither_OC_latency','neither_censor_upper'),
  value=c(phase1_n,calibration_n,validation_n,oc_n,horizon,alpha,lambda,master_seed,
    fap_absolute_tolerance,max_ic_recalibrations,lookup_grid_n,lookup_score_tolerance,
    log_or0,log_time0,log_hr0,1,'slope only exact scalar weighted convex rank solver',
    'mean-zero proper completed log-error distribution',1,'E[min(T,H+1)]',FALSE,
    'directional charts know component/direction/design magnitude, not actual magnitude; RAC omnibus',
    'z0 lognormal(log8,.65); z1 log-logistic(scale=exp(log8-.35), shape=1/.70)',
    'S_z(t)^HR with HR=1.5, not time scaling',neither_censor_upper))
write.csv(protocol,file.path(output,'protocol.csv'),row.names=FALSE)
information <- data.frame(method=methods,
  baseline_latency=c('AFT','AFT','PH','PH','PH'),
  patient_evidence=c('observed-data mixture LR','same observed-data mixture LR',
                    'observed-data mixture LR','author public-code posterior-weighted score',
                    'incidence and latency squared scores'),
  known_component=c(TRUE,TRUE,TRUE,TRUE,FALSE),
  known_direction=c(TRUE,TRUE,TRUE,TRUE,FALSE),
  known_design_magnitude=c(TRUE,TRUE,TRUE,TRUE,FALSE),
  actual_magnitude_supplied=FALSE,change_onset_supplied=FALSE,phase2_refitting=FALSE,
  design_OR=c('1.5 if cure/joint','1.5 if cure/joint','1.5 if cure/joint',
              '1.5 if cure/joint','none'),
  design_latency=c('time ratio .75 if latency/joint','time ratio .75 if latency/joint',
                   'hazard ratio 1.5 if latency/joint','hazard ratio 1.5 if latency/joint','none'),
  scope=c('proposed','accumulator ablation','directionally matched PH LR comparator',
          'fixed patient-level adaptation, not full published follow-up workflow',
          'formula-level overall four-boundary omnibus adaptation'))
write.csv(information,file.path(output,'method_information.csv'),row.names=FALSE)
capture.output(sessionInfo(),file=file.path(output,'session_info.txt'))
checkpoint()
cat('Completed in',as.numeric(difftime(Sys.time(),started,units='secs')),'seconds\n')
