# Deterministic, retrospective arithmetic illustration; not clinical monitoring.
# Uses all 299 records once and never simulates, selects a model, or calibrates an alarm.
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) stop("usage: Rscript illustrate_heart_failure.R PROJECT OUTPUT")
root <- normalizePath(args[1], mustWork = TRUE)
out <- normalizePath(args[2], mustWork = TRUE)
source(file.path(root, "代码/R/core_model.R"))
source(file.path(root, "代码/R/semiparametric_aftmc.R"))
source(file.path(root, "代码/R/aftmc_identified.R"))
source(file.path(root, "代码/R/ewma.R"))
raw <- read.csv(file.path(root, "原始数据/临床数据/heart_failure_clinical_records_dataset.csv"),
                check.names = FALSE)
stopifnot(nrow(raw) == 299L, sum(raw$DEATH_EVENT) == 96L,
          all(diff(raw$time) >= 0), all(raw$time > 0), !anyNA(raw))
variables <- c("age", "serum_creatinine", "serum_sodium")
scale_table <- data.frame(variable = variables,
                          sample_mean = vapply(raw[variables], mean, numeric(1)),
                          sample_sd = vapply(raw[variables], sd, numeric(1)))
data <- raw
for (v in variables) data[[paste0(v, "_z")]] <-
  (raw[[v]] - scale_table$sample_mean[scale_table$variable == v]) /
  scale_table$sample_sd[scale_table$variable == v]
incidence_vars <- paste0(variables, "_z")
latency_vars <- "age_z"
warnings <- character()
fit <- tryCatch(withCallingHandlers(fit_identified_aftmc(
  data, incidence_vars = incidence_vars, latency_vars = latency_vars,
  time_var = "time", status_var = "DEATH_EVENT"),
  warning = function(w) {warnings <<- c(warnings, conditionMessage(w)); invokeRestart("muffleWarning")}),
  error = function(e) {
    if (!is.null(e$history)) write.csv(e$history, file.path(out, "fit_history.csv"), row.names = FALSE)
    writeLines(conditionMessage(e), file.path(out, "fit_failure.txt"))
    stop(e)
  })
rho_c <- 1.5
rho_s <- 0.75
lambda <- 0.069
W <- identified_aftmc_log_lr(fit, data, rho_c = rho_c, rho_s = rho_s,
                            time_var = "time", status_var = "DEATH_EVENT")
prediction <- predict_identified_aftmc(fit, data, time_var = "time")
direct_W <- aft_mixture_loglik_contribution(data$time, data$DEATH_EVENT,
  prediction$incidence_lp, prediction$aft_lp, rho_s, rho_c, fit$baseline) -
  aft_mixture_loglik_contribution(data$time, data$DEATH_EVENT,
  prediction$incidence_lp, prediction$aft_lp, 1, 1, fit$baseline)
null_W <- identified_aftmc_log_lr(fit, data, rho_c = 1, rho_s = 1,
                                 time_var = "time", status_var = "DEATH_EVENT")
# Zero-start raw-score arithmetic only: no clinical IC mean or threshold is estimated.
ewma <- ewma_statistic(W, lambda)
cusum <- numeric(length(W))
for (i in seq_along(W)) cusum[i] <- max(0, W[i] + if (i > 1L) cusum[i-1L] else 0)
ewma_closed <- vapply(seq_along(W), function(i)
  sum(lambda * (1-lambda)^(i-seq_len(i)) * W[seq_len(i)]), numeric(1))
cum <- c(0, cumsum(W))
cusum_closed <- pmax(0, cum[-1L] - cummin(cum)[-length(cum)])
checks <- data.frame(
  check = c("all_log_lr_and_statistics_finite", "expanded_vs_full_loglik_max_abs",
            "null_lr_max_abs", "ewma_recurrence_vs_closed_form_max_abs",
            "cusum_recurrence_vs_closed_form_max_abs", "centered_error_mean_abs",
            "preserved_followup_sorted_record_order", "serialized_fit_lr_max_abs",
            "raw_vs_translated_ewma_max_abs"),
  value = c(as.numeric(all(is.finite(c(W, ewma, cusum)))), max(abs(W-direct_W)),
            max(abs(null_W)), max(abs(ewma-ewma_closed)), max(abs(cusum-cusum_closed)),
            abs(fit$diagnostics$mean_after_centering), as.numeric(all(diff(data$time) >= 0)), NA_real_,
            max(abs(ewma - (ewma_statistic(W-0.123, lambda, e0=-0.123)+0.123)))),
  threshold = c(1, 1e-10, 1e-12, 1e-12, 1e-10, 1e-6, 1, 1e-12, 1e-12))
saveRDS(fit, file.path(out, "fitted_model.rds"))
serialized_W <- identified_aftmc_log_lr(readRDS(file.path(out, "fitted_model.rds")), data,
  rho_c = rho_c, rho_s = rho_s, time_var = "time", status_var = "DEATH_EVENT")
checks$value[checks$check == "serialized_fit_lr_max_abs"] <- max(abs(W-serialized_W))
checks$passed <- ifelse(grepl("all_log|preserved", checks$check),
                        checks$value == checks$threshold, checks$value <= checks$threshold)
stopifnot(all(checks$passed))
coefficients <- data.frame(
  component = c(rep("incidence_log_odds_of_susceptibility", length(fit$incidence_coef)),
                rep("latency_log_time", length(fit$latency_coef))),
  term = c("intercept", incidence_vars, "mean_normalized_intercept", latency_vars),
  estimate = c(fit$incidence_coef, fit$latency_coef))
d <- fit$diagnostics
diagnostics <- data.frame(metric = c("n", "deaths", "censored", "iterations", "converged",
  "coef_change", "survivor_change", "mixture_survivor_change", "posterior_change",
  "final_prediction_change", "final_posterior_change", "rank_certificate",
  "mean_after_centering", "mean_integration_error", "rho_c", "rho_s", "lambda",
  "log_lr_sample_mean", "log_lr_min", "log_lr_q25", "log_lr_median",
  "log_lr_q75", "log_lr_max", "log_lr_sd", "ewma_min", "ewma_max", "ewma_final",
  "cusum_min", "cusum_max", "cusum_final", "probability_susceptible_min",
  "probability_susceptible_mean", "probability_susceptible_max"),
  value = c(nrow(data), sum(data$DEATH_EVENT), sum(1-data$DEATH_EVENT), d$iterations,
  as.numeric(d$converged), d$coef_change, d$survivor_change, d$mixture_survivor_change,
  d$posterior_change, d$final_prediction_change, d$final_posterior_change,
  d$rank_certificate, d$mean_after_centering, d$mean_integration_error,
  rho_c, rho_s, lambda, mean(W), min(W), quantile(W, .25), median(W),
  quantile(W, .75), max(W), sd(W), min(ewma), max(ewma), tail(ewma, 1),
  min(cusum), max(cusum), tail(cusum, 1), min(prediction$probability_uncured),
  mean(prediction$probability_uncured), max(prediction$probability_uncured)))
patient <- data.frame(computational_record_index = seq_len(nrow(data)),
  followup_days = data$time, death_event = data$DEATH_EVENT,
  age_z = data$age_z, serum_creatinine_z = data$serum_creatinine_z,
  serum_sodium_z = data$serum_sodium_z,
  working_probability_susceptible = prediction$probability_uncured,
  log_lr = W, zero_start_raw_ewma = ewma, same_lr_cusum = cusum)
write.csv(scale_table, file.path(out, "covariate_scaling.csv"), row.names = FALSE)
write.csv(coefficients, file.path(out, "coefficients.csv"), row.names = FALSE)
write.csv(diagnostics, file.path(out, "diagnostics.csv"), row.names = FALSE)
write.csv(d$history, file.path(out, "fit_history.csv"), row.names = FALSE)
write.csv(patient, file.path(out, "patient_evidence.csv"), row.names = FALSE)
write.csv(checks, file.path(out, "numerical_checks.csv"), row.names = FALSE)
writeLines(unique(warnings), file.path(out, "fit_warnings.txt"))
writeLines(capture.output(sessionInfo()), file.path(out, "session_info.txt"))
cat("Prespecified one-fit retrospective implementation illustration completed.\n")
print(diagnostics, row.names = FALSE)
print(checks, row.names = FALSE)
