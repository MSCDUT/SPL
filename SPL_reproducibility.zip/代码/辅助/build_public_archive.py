"""Package the current code and frozen simulation evidence; never run analyses."""
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile


root = Path(sys.argv[1]).resolve(strict=True)
output = root / "公开存档" / "SPL_reproducibility.zip"
assert (root / "DECISIVE_AUDIT.md").is_file()
code = [
    "代码/rebuild_simulation.R", "代码/build_simulation_tables.R",
    "代码/decisive_audit.R", "代码/decisive_convergence.R", "代码/README.md",
    "代码/R/core_model.R", "代码/R/ewma.R", "代码/R/monte_carlo.R",
    "代码/R/semiparametric_aftmc.R", "代码/R/rac_ewma.R",
    "代码/R/rac_penphcure_adapter.R", "代码/R/m4_shared_misspec_simulation.R",
    "代码/R/aftmc_identified.R", "代码/tests/test_aftmc_identified.R",
    "代码/辅助/illustrate_heart_failure.R",
    "代码/辅助/build_public_archive.py",
    "代码/参考代码/RAC_EWMA_CODE_AUDIT.md",
    "代码/参考代码/RAC_EWMA_SOURCE.md",
]
files = [root / p for p in code]
for directory in ["原始数据/重构模拟", "原始数据/决定性审计"]:
    files += sorted(p for p in (root / directory).rglob("*") if p.is_file())
for p in files:
    assert p.is_file() and not p.is_symlink(), p
    assert root in p.resolve().parents, p


def portable_text(text):
    """Normalize execution-path labels only in public provenance copies."""
    text = text.replace(str(root), "PROJECT")
    return re.sub(r"/private/tmp/[A-Za-z0-9_.-]+", "TEMP_RUNTIME", text)


manifest = {
    "title": "Directional Likelihood-Ratio Monitoring under a Semiparametric AFT Cure Model: code and simulation evidence",
    "creators": ["Meng Cheng", "Liu Liu", "Xinrui Li", "Ye He"],
    "status": "local preparation; no repository publication asserted",
    "analysis_run": False,
    "private_clinical_records_included": False,
    "third_party_original_source_included": False,
    "files": [],
}
output.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    readme = (root / "公开存档/README.md").read_bytes()
    archive.writestr("README.md", readme)
    manifest["files"].append({"path": "README.md", "sha256": hashlib.sha256(readme).hexdigest()})
    for p in files:
        name = str(p.relative_to(root))
        data = p.read_bytes()
        original = hashlib.sha256(data).hexdigest()
        normalized = False
        if p.name in {"manifest.json", "stdout.txt", "stderr.txt", "session_info.txt"}:
            public = portable_text(data.decode("utf-8")).encode("utf-8")
            normalized = public != data
            data = public
        archive.writestr(name, data)
        manifest["files"].append({"path": name, "sha256": hashlib.sha256(data).hexdigest(),
                                  "source_sha256": original, "path_labels_normalized": normalized})
    archive.writestr("public_manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    saved = json.loads(archive.read("public_manifest.json"))
    for item in saved["files"]:
        assert hashlib.sha256(archive.read(item["path"])).hexdigest() == item["sha256"]
    assert len(archive.namelist()) == len(saved["files"]) + 1
print(f"PASS: {output}; {len(saved['files'])} verified files; {output.stat().st_size} bytes; no analysis run")
